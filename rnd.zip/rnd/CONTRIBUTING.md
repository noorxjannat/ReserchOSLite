# Contributing to ResearchPilot AI 🚀

Welcome to **ResearchPilot AI**! We are thrilled to welcome your contributions during **Hacktoberfest** and beyond.

ResearchPilot AI is an autonomous multi-agent research workflow assistant built to help undergraduates, postgraduates, and researchers move from raw hypotheses to publication-grade research blueprints.

---

## 🎃 Hacktoberfest Participation Guidelines

1. **Find an Issue or Propose One**:
   - Check the issue tracker for labels: `hacktoberfest`, `good first issue`, `domain-plugin`, or `enhancement`.
   - If proposing a new scientific domain or tool, please open an issue first.
2. **Quality Over Quantity**:
   - We value meaningful scientific and architectural contributions.
   - PRs containing spam, automated superficial edits, or whitespace changes will be labeled `invalid`/`spam`.
3. **Follow Architectural Principles**:
   - Domain-Agnostic Core + Domain-Specific Plugins.
   - Provider-Agnostic LLM Layer (always support the Mock engine for zero-cost testing).

---

## 🛠️ Development Setup

### 1. Clone & Set Up Environment
```bash
git clone https://github.com/your-username/ResearchPilot-AI.git
cd ResearchPilot-AI

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env if you wish to configure Gemini or OpenAI keys.
# By default, LLM_PROVIDER=mock allows full offline operation!
```

### 3. Run Test Suite
```bash
python -m pytest -v
```

### 4. Launch Application
```bash
# Start Streamlit Dashboard
python run.py --frontend

# Or start FastAPI Backend
python run.py --backend
```

---

## 🧩 Adding a New Scientific Domain Plugin

ResearchPilot AI is built to expand across **Agriculture**, **Medicine**, **Chemistry**, and beyond!

To add a new domain plugin (e.g., `agriculture`):

1. Create a directory: `domains/agriculture/`
2. Create `domain_prompt.py`:
   ```python
   AGRICULTURE_SYSTEM_ENHANCEMENT = """
   You are acting within the Agriculture & Precision Farming scientific domain.
   Emphasize field trial controls, multi-spectral vegetative indices (NDVI), and climatic variables.
   """
   ```
3. Create `domain_metrics.py`:
   Define relevant metrics (e.g., Yield (kg/ha), NDVI, Water Use Efficiency).
4. Create `domain_tools.py`:
   Add computational helpers (e.g., GDD calculation, fertilizer dosage estimator).
5. Create `domains/agriculture/__init__.py`:
   Subclass `DomainPlugin` and call `PluginRegistry.register(AgriculturePlugin())`.
6. Add unit tests in `tests/test_plugins.py` and submit your Pull Request!

---

## 📋 Pull Request Checklist

Before submitting your PR, ensure:
- [ ] Code follows PEP 8 style conventions.
- [ ] Type hints and docstrings are included for all public functions and classes.
- [ ] All tests pass: `python -m pytest -v`.
- [ ] New features include corresponding unit tests in `tests/`.
- [ ] No API keys or sensitive credentials are committed.

Thank you for contributing to open science with ResearchPilot AI! 🔬
