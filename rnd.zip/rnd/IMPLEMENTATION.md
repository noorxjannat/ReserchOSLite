# ResearchPilot AI - Implementation Blueprint

**"An Autonomous Multi-Agent Research Workflow Assistant"**  
*Hacktoberfest Ready Open-Source MVP*

---

## 1. Executive Summary & Vision

ResearchPilot AI is a modular, multi-agent scientific research workspace engineered to transform raw research ideas into rigorous, publication-ready research blueprints. Designed for undergraduate students, postgraduate researchers, and scientific labs, ResearchPilot AI automates the cognitive pipeline of early-stage scientific inquiry:

```
+-----------------------------------------------------------------------------------------+
|                                    User Research Idea                                   |
+-----------------------------------------------------------------------------------------+
                                             |
                                             v
+-----------------------------------------------------------------------------------------+
|                                 Research Director Agent                                 |
|                     (Goal decomposition, domain routing, state graph)                   |
+-----------------------------------------------------------------------------------------+
       |                  |                  |                  |                  |
       v                  v                  v                  v                  v
+--------------+   +--------------+   +--------------+   +--------------+   +--------------+
| Topic Agent  |-->| Literature   |-->|  Gap Agent   |-->| Methodology  |-->| Report Agent |
| (Keywords &  |   | Agent        |   | (Contrasts & |   | Agent (Study |   | (Structured  |
| Domain Taxo) |   | (arXiv+S2)   |   | Whitespaces) |   | Design)      |   | Blueprint)   |
+--------------+   +--------------+   +--------------+   +--------------+   +--------------+
                                                                                   ^
                                                                                   |
                                      +--------------------------------------------+
                                      | Data Agent & RAG Retrieval
                                      | (Statistical & ML profiling, Doc retrieval)
```

---

## 2. Architectural Blueprint

### 2.1 Core Pillars
1. **Domain-Agnostic Core + Domain-Specific Plugin Architecture**:
   - Agnostic orchestrator and agent communication protocols.
   - Plug-and-play domain modules (`domains/cse`, `domains/eee`, `domains/genetics`, etc.) providing domain-specific evaluation metrics, prompt modifications, and validation criteria.
2. **Provider-Agnostic LLM Layer**:
   - Universal adapter supporting **OpenAI**, **Gemini**, and an intelligent **Offline/Local Deterministic Heuristic Engine** for instant developer testing and zero-cost CI/CD workflows.
3. **Multi-Agent Orchestration via LangGraph StateGraph**:
   - Formal StateGraph architecture managing pipeline states, message passing, check-pointing, and asynchronous agent triggers.
4. **End-to-End Scientific RAG & Analytics**:
   - Scientific paper ingestion (PDF/text), chunking, vector embeddings, ChromaDB / lightweight in-memory vector index.
   - Empirical data agent featuring statistical summary, correlation matrices, ML classification & regression, interactive Plotly visualizations, and automated scientific interpretation.

---

## 3. Directory Layout

```
ResearchPilot-AI/
├── app.py                      # Interactive Streamlit scientific dashboard
├── run.py                      # Multi-service launcher (API + Streamlit)
├── config.py                   # Centralized Pydantic configuration & env validation
├── requirements.txt            # Dependency manifest
├── .env.example                # Sample environment variables
├── IMPLEMENTATION.md           # Engineering implementation plan (this document)
├── project_context_and_handover.md # Living status & handover log
├── backend/
│   ├── main.py                 # FastAPI REST API & webhook endpoints
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── research_director.py # Orchestrator & LangGraph state machine
│   │   ├── topic_agent.py       # Topic understanding, taxonomy & keyword mining
│   │   ├── literature_agent.py  # Literature intelligence (arXiv, Semantic Scholar)
│   │   ├── gap_agent.py         # Research gap analysis & white-space discovery
│   │   ├── methodology_agent.py # Research design & experimental setup
│   │   ├── data_agent.py        # Empirical analysis & ML interpretation
│   │   └── report_agent.py      # Publication-grade research blueprint generation
│   ├── rag/
│   │   ├── __init__.py
│   │   ├── embeddings.py        # Universal embedding interface
│   │   ├── vector_store.py      # ChromaDB / Vector store manager
│   │   └── retriever.py         # Scientific context retriever
│   └── services/
│       ├── __init__.py
│       ├── llm_service.py       # OpenAI & Gemini unified abstraction
│       ├── paper_search.py      # arXiv & Semantic Scholar live integration
│       └── document_processor.py# PDF & text parser with citation-aware chunking
├── domains/
│   ├── __init__.py
│   ├── base.py                 # Abstract DomainPlugin interface & registry
│   ├── cse/                    # Computer Science & Engineering Plugin
│   │   ├── __init__.py
│   │   ├── domain_prompt.py
│   │   ├── domain_tools.py
│   │   └── domain_metrics.py
│   ├── eee/                    # Electrical & Electronics Engineering Plugin
│   │   ├── __init__.py
│   │   ├── domain_prompt.py
│   │   ├── domain_tools.py
│   │   └── domain_metrics.py
│   └── genetics/               # Genetic Engineering & Bioinformatics Plugin
│       ├── __init__.py
│       ├── domain_prompt.py
│       ├── domain_tools.py
│       └── domain_metrics.py
├── data/
│   ├── papers/                 # Sample research papers & corpus
│   └── datasets/               # Sample scientific datasets (CSE, EEE, Genetics)
├── analysis/
│   ├── __init__.py
│   ├── statistics.py           # Descriptive & inferential statistics
│   ├── visualization.py        # Plotly & Matplotlib chart generation
│   └── ml_models.py            # Automated ML classification/regression pipelines
├── tests/
│   ├── test_agents.py          # Agent unit tests
│   ├── test_data_analysis.py   # Statistical & ML pipeline tests
│   ├── test_paper_search.py    # Literature API tests
│   ├── test_plugins.py         # Domain plugin architecture tests
│   └── test_api.py             # FastAPI integration tests
├── README.md                   # Hacktoberfest-grade documentation & architecture
├── CONTRIBUTING.md             # Open-source contribution guidelines
└── LICENSE                     # Apache 2.0 Open Source License
```

---

## 4. Phased Implementation Roadmap

### Phase 1: Core Multi-Agent Engine & Backend Pipeline
- [x] Environment configuration & directory architecture.
- [ ] Universal LLM Service (`backend/services/llm_service.py`) supporting Gemini (`google-genai`), OpenAI, and Mock Engine.
- [ ] Literature Search Client (`backend/services/paper_search.py`) with arXiv API & Semantic Scholar API.
- [ ] Domain-Agnostic Core & Domain Plugin Architecture (`domains/base.py`, `cse`, `eee`, `genetics`).
- [ ] Multi-Agent Workflows (`backend/agents/*`):
  - Topic Agent
  - Literature Agent
  - Gap Agent
  - Methodology Agent
  - Report Agent
  - Research Director Orchestrator with LangGraph / StateGraph.
- [ ] FastAPI Application (`backend/main.py`) exposing workflow endpoints.

### Phase 2: RAG Retrieval, Document Processing & Empirical Data Agent
- [ ] Scientific Document Processor (`backend/services/document_processor.py`) for PDF extraction and semantic chunking.
- [ ] Embedding & Vector Store Layer (`backend/rag/*`) with ChromaDB support and query retriever.
- [ ] Data Analysis Engine (`analysis/*`):
  - Parametric & Non-parametric descriptive statistics.
  - Pearson & Spearman correlation heatmaps.
  - Automated ML Model fitting (Classification & Regression) with Scikit-Learn.
  - Feature importance and model diagnostics.
- [ ] Data Analysis Agent (`backend/agents/data_agent.py`) translating numerical findings into scientific prose.
- [ ] Synthetic Demonstration Datasets with experimental caveats.

### Phase 3: Scientific Dashboard, Testing Suite & Hacktoberfest Assets
- [ ] Multi-stage Streamlit Web Interface (`app.py`):
  - Stage 1: Research Input & Director Strategy.
  - Stage 2: Literature Intelligence & Paper Explorer.
  - Stage 3: Research Gap White-space Matrix.
  - Stage 4: Experimental Methodology Designer.
  - Stage 5: Empirical Data Analytics & ML Lab.
  - Stage 6: Final Research Blueprint & LaTeX/Markdown Exporter.
- [ ] Pytest Test Suite (`tests/*`) verifying agent contracts, data analysis, search, plugins, and endpoints.
- [ ] Production Open-Source Artifacts (`README.md`, `CONTRIBUTING.md`, `LICENSE`, `.env.example`).
- [ ] Phase Completion & Handover Documentation (`project_context_and_handover.md`).
