"""
Scientific Data Analysis Package for ResearchPilot AI.
"""

from analysis.statistics import compute_descriptive_statistics, compute_correlation_matrix
from analysis.visualization import (
    create_distribution_plot,
    create_scatter_plot,
    create_correlation_heatmap,
    create_feature_importance_plot
)
from analysis.ml_models import train_classification_models, train_regression_models

__all__ = [
    "compute_descriptive_statistics",
    "compute_correlation_matrix",
    "create_distribution_plot",
    "create_scatter_plot",
    "create_correlation_heatmap",
    "create_feature_importance_plot",
    "train_classification_models",
    "train_regression_models"
]
