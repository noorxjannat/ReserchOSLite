"""
Automated Machine Learning Model Training & Evaluation Engine.

Fits classification and regression models using Scikit-Learn, extracts metrics and feature importances.
"""

from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_squared_error, mean_absolute_error, r2_score


def train_classification_models(
    df: pd.DataFrame,
    target_col: str,
    feature_cols: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Train multiple classification baselines and return benchmark metrics."""
    data = df.copy().dropna(subset=[target_col])
    if len(data) < 20:
        return {"error": "Insufficient samples for machine learning training (min 20 samples required)."}

    y_raw = data[target_col]
    le = LabelEncoder()
    y = le.fit_transform(y_raw.astype(str))
    classes = [str(c) for c in le.classes_]

    if feature_cols:
        x_cols = [c for c in feature_cols if c in data.columns and c != target_col]
    else:
        x_cols = [c for c in data.select_dtypes(include=[np.number]).columns if c != target_col]

    if not x_cols:
        return {"error": "No valid numeric feature columns available for training."}

    X_numeric = data[x_cols]
    imputer = SimpleImputer(strategy="median")
    X_imputed = imputer.fit_transform(X_numeric)

    # Train / test split (80 / 20)
    X_train, X_test, y_train, y_test = train_test_split(
        X_imputed, y, test_size=0.20, random_state=42, stratify=y if len(classes) < len(y) / 5 else None
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=80, max_depth=4, random_state=42)
    }

    results = []
    feature_importances = []

    for name, model in models.items():
        try:
            if name == "Logistic Regression":
                model.fit(X_train_scaled, y_train)
                y_pred = model.predict(X_test_scaled)
            else:
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)

            acc = float(accuracy_score(y_test, y_pred))
            prec = float(precision_score(y_test, y_pred, average="macro", zero_division=0))
            rec = float(recall_score(y_test, y_pred, average="macro", zero_division=0))
            f1 = float(f1_score(y_test, y_pred, average="macro", zero_division=0))

            results.append({
                "model": name,
                "accuracy": round(acc, 4),
                "precision": round(prec, 4),
                "recall": round(rec, 4),
                "f1_score": round(f1, 4)
            })

            if name == "Random Forest":
                importances = model.feature_importances_
                feature_importances = [
                    {"feature": col, "importance": round(float(imp), 4)}
                    for col, imp in zip(x_cols, importances)
                ]
                feature_importances.sort(key=lambda x: x["importance"], reverse=True)
        except Exception as e:
            results.append({"model": name, "error": str(e)})

    # Identify best performing model
    valid_results = [r for r in results if "f1_score" in r]
    best_model = max(valid_results, key=lambda x: x["f1_score"])["model"] if valid_results else "None"

    return {
        "task_type": "Classification",
        "target_column": target_col,
        "classes": classes,
        "features_used": x_cols,
        "sample_count": len(data),
        "test_sample_count": len(X_test),
        "benchmark_results": results,
        "best_model": best_model,
        "feature_importances": feature_importances
    }


def train_regression_models(
    df: pd.DataFrame,
    target_col: str,
    feature_cols: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Train multiple regression baselines and return evaluation metrics."""
    data = df.copy().dropna(subset=[target_col])
    if len(data) < 20:
        return {"error": "Insufficient samples for machine learning training (min 20 samples required)."}

    y = data[target_col].astype(float).values

    if feature_cols:
        x_cols = [c for c in feature_cols if c in data.columns and c != target_col]
    else:
        x_cols = [c for c in data.select_dtypes(include=[np.number]).columns if c != target_col]

    if not x_cols:
        return {"error": "No valid numeric feature columns available for regression."}

    X_numeric = data[x_cols]
    imputer = SimpleImputer(strategy="median")
    X_imputed = imputer.fit_transform(X_numeric)

    # Train / test split (80 / 20)
    X_train, X_test, y_train, y_test = train_test_split(
        X_imputed, y, test_size=0.20, random_state=42
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = {
        "Ridge Regression": Ridge(alpha=1.0, random_state=42),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, max_depth=8, random_state=42),
        "Gradient Boosting Regressor": GradientBoostingRegressor(n_estimators=80, max_depth=4, random_state=42)
    }

    results = []
    feature_importances = []

    for name, model in models.items():
        try:
            if name == "Ridge Regression":
                model.fit(X_train_scaled, y_train)
                y_pred = model.predict(X_test_scaled)
            else:
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)

            rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
            mae = float(mean_absolute_error(y_test, y_pred))
            r2 = float(r2_score(y_test, y_pred))

            results.append({
                "model": name,
                "rmse": round(rmse, 4),
                "mae": round(mae, 4),
                "r2_score": round(r2, 4)
            })

            if name == "Random Forest Regressor":
                importances = model.feature_importances_
                feature_importances = [
                    {"feature": col, "importance": round(float(imp), 4)}
                    for col, imp in zip(x_cols, importances)
                ]
                feature_importances.sort(key=lambda x: x["importance"], reverse=True)
        except Exception as e:
            results.append({"model": name, "error": str(e)})

    valid_results = [r for r in results if "r2_score" in r]
    best_model = max(valid_results, key=lambda x: x["r2_score"])["model"] if valid_results else "None"

    return {
        "task_type": "Regression",
        "target_column": target_col,
        "features_used": x_cols,
        "sample_count": len(data),
        "test_sample_count": len(X_test),
        "benchmark_results": results,
        "best_model": best_model,
        "feature_importances": feature_importances
    }
