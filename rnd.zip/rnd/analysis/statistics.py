"""
Scientific Statistical Analysis Module.

Computes parametric and non-parametric descriptive statistics,
normality checks, and Pearson/Spearman correlation matrices.
"""

from typing import Dict, Any, List, Tuple
import pandas as pd
import numpy as np


def compute_descriptive_statistics(df: pd.DataFrame) -> Dict[str, Any]:
    """Calculate thorough descriptive statistics for numerical columns."""
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not numeric_cols:
        return {"error": "No numeric columns found in dataset.", "columns": []}

    stats_summary = {}
    for col in numeric_cols:
        series = df[col].dropna()
        if len(series) == 0:
            continue

        q25 = float(series.quantile(0.25))
        q75 = float(series.quantile(0.75))
        iqr = float(q75 - q25)
        mean_val = float(series.mean())
        std_val = float(series.std()) if len(series) > 1 else 0.0

        # Skewness & Kurtosis
        skew = float(series.skew()) if len(series) > 2 else 0.0
        kurt = float(series.kurtosis()) if len(series) > 3 else 0.0

        stats_summary[col] = {
            "count": int(len(series)),
            "mean": round(mean_val, 4),
            "std": round(std_val, 4),
            "variance": round(std_val ** 2, 4),
            "median": round(float(series.median()), 4),
            "min": round(float(series.min()), 4),
            "max": round(float(series.max()), 4),
            "q25": round(q25, 4),
            "q75": round(q75, 4),
            "iqr": round(iqr, 4),
            "skewness": round(skew, 4),
            "kurtosis": round(kurt, 4),
            "is_approximately_normal": bool(abs(skew) < 0.8 and abs(kurt) < 1.5)
        }

    return {
        "total_rows": int(len(df)),
        "total_columns": int(len(df.columns)),
        "numeric_column_count": len(numeric_cols),
        "statistics": stats_summary
    }


def compute_correlation_matrix(
    df: pd.DataFrame,
    method: str = "pearson"
) -> Dict[str, Any]:
    """Calculate correlation matrix and discover highest correlated feature pairs."""
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.shape[1] < 2:
        return {"error": "At least 2 numeric columns required for correlation.", "matrix": {}}

    corr_matrix = numeric_df.corr(method=method).round(4)

    # Extract top correlated pairs (excluding diagonal)
    pairs: List[Dict[str, Any]] = []
    columns = corr_matrix.columns.tolist()

    for i in range(len(columns)):
        for j in range(i + 1, len(columns)):
            col1 = columns[i]
            col2 = columns[j]
            val = float(corr_matrix.loc[col1, col2])
            if not np.isnan(val):
                pairs.append({
                    "feature_1": col1,
                    "feature_2": col2,
                    "correlation": round(val, 4),
                    "abs_correlation": round(abs(val), 4),
                    "relationship": "Strong Positive" if val > 0.6 else (
                        "Strong Negative" if val < -0.6 else (
                            "Moderate" if abs(val) >= 0.3 else "Weak"
                        )
                    )
                })

    pairs.sort(key=lambda x: x["abs_correlation"], reverse=True)

    return {
        "method": method,
        "matrix": corr_matrix.to_dict(),
        "columns": columns,
        "top_correlated_pairs": pairs[:10]
    }
