"""
Scientific Visualization Module.

Generates interactive Plotly figures and publication-quality diagrams.
"""

from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go


def create_distribution_plot(
    df: pd.DataFrame,
    column: str,
    title: Optional[str] = None
) -> go.Figure:
    """Generate distribution histogram with marginal box plot."""
    fig = px.histogram(
        df,
        x=column,
        marginal="box",
        nbins=35,
        title=title or f"Distribution Analysis of {column}",
        color_discrete_sequence=["#1f77b4"],
        template="plotly_white"
    )
    fig.update_layout(
        font=dict(family="Inter, Roboto, sans-serif"),
        title_font_size=16,
        xaxis_title=column,
        yaxis_title="Frequency"
    )
    return fig


def create_scatter_plot(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    color_col: Optional[str] = None,
    trendline: bool = True
) -> go.Figure:
    """Generate scientific scatter plot with trendline."""
    fig = px.scatter(
        df,
        x=x_col,
        y=y_col,
        color=color_col if color_col in df.columns else None,
        trendline="ols" if trendline and pd.api.types.is_numeric_dtype(df[x_col]) and pd.api.types.is_numeric_dtype(df[y_col]) else None,
        title=f"Empirical Bivariate Relationship: {y_col} vs {x_col}",
        template="plotly_white",
        color_discrete_sequence=px.colors.qualitative.Prism
    )
    fig.update_layout(
        font=dict(family="Inter, Roboto, sans-serif"),
        title_font_size=16
    )
    return fig


def create_correlation_heatmap(df: pd.DataFrame) -> go.Figure:
    """Generate interactive correlation heatmap."""
    numeric_df = df.select_dtypes(include=[np.number])
    corr = numeric_df.corr().round(2)

    fig = px.imshow(
        corr,
        text_auto=True,
        aspect="auto",
        color_continuous_scale="RdBu_r",
        zmin=-1,
        zmax=1,
        title="Pearson Feature Correlation Matrix",
        template="plotly_white"
    )
    fig.update_layout(
        font=dict(family="Inter, Roboto, sans-serif"),
        title_font_size=16
    )
    return fig


def create_feature_importance_plot(
    feature_names: List[str],
    importances: List[float],
    title: str = "Relative Feature Importance (MDI)"
) -> go.Figure:
    """Generate horizontal bar chart of predictive feature importances."""
    df_imp = pd.DataFrame({
        "Feature": feature_names,
        "Importance": importances
    }).sort_values(by="Importance", ascending=True)

    fig = px.bar(
        df_imp,
        x="Importance",
        y="Feature",
        orientation="h",
        title=title,
        color="Importance",
        color_continuous_scale="Blues",
        template="plotly_white"
    )
    fig.update_layout(
        font=dict(family="Inter, Roboto, sans-serif"),
        title_font_size=16,
        xaxis_title="Importance Weight",
        yaxis_title="Feature Name"
    )
    return fig


def create_volcano_plot(
    df: pd.DataFrame,
    log2fc_col: str = "log2_fold_change",
    pval_col: str = "padj_fdr"
) -> go.Figure:
    """Generate genomic differential expression Volcano Plot."""
    df_plot = df.copy()
    df_plot["neg_log10_p"] = -np.log10(np.clip(df_plot[pval_col], 1e-15, 1.0))

    # Significance status
    conditions = [
        (df_plot[pval_col] < 0.05) & (df_plot[log2fc_col] >= 1.0),
        (df_plot[pval_col] < 0.05) & (df_plot[log2fc_col] <= -1.0),
        (df_plot[pval_col] < 0.05) & (df_plot[log2fc_col].abs() < 1.0)
    ]
    choices = ["Up-Regulated", "Down-Regulated", "Significant Low Fold"]
    df_plot["Regulation"] = np.select(conditions, choices, default="Non-Significant")

    color_map = {
        "Up-Regulated": "#2ecc71",
        "Down-Regulated": "#e74c3c",
        "Significant Low Fold": "#f39c12",
        "Non-Significant": "#bdc3c7"
    }

    fig = px.scatter(
        df_plot,
        x=log2fc_col,
        y="neg_log10_p",
        color="Regulation",
        color_discrete_map=color_map,
        title="RNA-Seq Differential Expression Volcano Plot",
        template="plotly_white",
        hover_data=[c for c in ["gene_id"] if c in df_plot.columns]
    )
    fig.add_vline(x=1.0, line_dash="dash", line_color="gray")
    fig.add_vline(x=-1.0, line_dash="dash", line_color="gray")
    fig.add_hline(y=-np.log10(0.05), line_dash="dash", line_color="gray")
    fig.update_layout(
        xaxis_title="Log2 Fold Change",
        yaxis_title="-Log10 (Adjusted P-Value)",
        font=dict(family="Inter, Roboto, sans-serif")
    )
    return fig
