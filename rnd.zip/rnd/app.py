"""
ResearchPilot AI - Streamlit Scientific Dashboard.

Autonomous Multi-Agent Research Workflow Assistant for Students, Researchers & Scientists.
"""

import os
import io
import time
from pathlib import Path
from typing import Optional, List, Dict, Any

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px

# Configuration & Backend Imports
from config import settings
from domains.base import PluginRegistry
import domains.cse
import domains.eee
import domains.genetics

from backend.agents.research_director import ResearchDirectorAgent, ResearchWorkflowState
from backend.agents.topic_agent import TopicUnderstandingAgent
from backend.agents.literature_agent import LiteratureIntelligenceAgent
from backend.agents.gap_agent import ResearchGapAgent
from backend.agents.methodology_agent import MethodologyAgent
from backend.agents.report_agent import ReportGeneratorAgent
from backend.agents.data_agent import DataAnalysisAgent
from backend.services.paper_search import PaperSearchService
from backend.services.document_processor import DocumentProcessor
from backend.rag.vector_store import ScientificVectorStore
from backend.rag.retriever import ScientificRAGRetriever
from backend.services.llm_service import get_llm_service
from analysis.statistics import compute_descriptive_statistics, compute_correlation_matrix
from analysis.visualization import (
    create_distribution_plot,
    create_scatter_plot,
    create_correlation_heatmap,
    create_feature_importance_plot,
    create_volcano_plot
)
from analysis.ml_models import train_classification_models, train_regression_models

# --- Page Configuration ---
st.set_page_config(
    page_title="ResearchPilot AI | Autonomous Research Assistant",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- Custom Styling ---
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    
    .main-header {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        padding: 1.8rem 2rem;
        border-radius: 12px;
        color: white;
        margin-bottom: 1.5rem;
        border-left: 6px solid #3b82f6;
    }
    .main-header h1 {
        color: #f8fafc;
        margin: 0;
        font-size: 2.1rem;
        font-weight: 700;
    }
    .main-header p {
        color: #94a3b8;
        margin-top: 0.4rem;
        font-size: 1rem;
    }
    
    .workflow-step-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        margin-right: 8px;
    }
    
    .card-box {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 1.2rem;
        margin-bottom: 1rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .highlight-banner {
        background-color: #eff6ff;
        border-left: 4px solid #3b82f6;
        padding: 1rem 1.2rem;
        border-radius: 6px;
        margin: 1rem 0;
    }
    
    .disclaimer-box {
        background-color: #fffbeb;
        border-left: 4px solid #f59e0b;
        padding: 0.8rem 1rem;
        border-radius: 6px;
        color: #92400e;
        font-size: 0.9rem;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# --- Session State Management ---
if "workflow_state" not in st.session_state:
    st.session_state.workflow_state = None
if "vector_store" not in st.session_state:
    st.session_state.vector_store = ScientificVectorStore()
if "retriever" not in st.session_state:
    st.session_state.retriever = ScientificRAGRetriever(vector_store=st.session_state.vector_store)
if "doc_processor" not in st.session_state:
    st.session_state.doc_processor = DocumentProcessor()
if "current_df" not in st.session_state:
    st.session_state.current_df = None
if "current_df_name" not in st.session_state:
    st.session_state.current_df_name = ""
if "analysis_report" not in st.session_state:
    st.session_state.analysis_report = None


# --- Sidebar Navigation & Settings ---
with st.sidebar:
    st.image("https://img.shields.io/badge/ResearchPilot-AI_v1.0-blue?style=for-the-badge&logo=blueprint", use_container_width=True)
    st.markdown("### 🧭 Workflow Navigation")
    
    page = st.radio(
        "Select Research Stage:",
        [
            "1. 💡 Research Input & Director",
            "2. 📚 Literature Explorer & RAG",
            "3. 🔍 Research Gap Matrix",
            "4. ⚙️ Methodology Designer",
            "5. 📊 Empirical Data Lab",
            "6. 📄 Final Blueprint & Export"
        ],
        index=0
    )
    
    st.divider()
    st.markdown("### ⚙️ Engine Settings")
    llm_provider = st.selectbox(
        "LLM Provider:",
        ["mock", "gemini", "openai"],
        format_func=lambda x: {
            "mock": "Mock Scientific Engine (Offline / Free)",
            "gemini": "Google Gemini API",
            "openai": "OpenAI API"
        }[x]
    )
    
    custom_api_key = ""
    if llm_provider != "mock":
        custom_api_key = st.text_input(
            f"{llm_provider.capitalize()} API Key:",
            type="password",
            help="Optional if set in .env"
        )
    
    domain_choice = st.selectbox(
        "Domain Plugin:",
        ["auto", "cse", "eee", "genetics"],
        format_func=lambda x: {
            "auto": "🤖 Auto-Detect Domain",
            "cse": "💻 Computer Science / AI",
            "eee": "⚡ Electrical Engineering",
            "genetics": "🧬 Genetics & Bioinformatics"
        }[x]
    )
    
    st.divider()
    st.markdown("**Hacktoberfest MVP** | Open-Source Research Platform")
    if st.button("Reset Workflow"):
        st.session_state.workflow_state = None
        st.session_state.analysis_report = None
        st.rerun()


# --- Progress Bar Visualization ---
def render_workflow_progress(current_stage_num: int):
    stages = ["Idea", "Literature", "Gap", "Methodology", "Data Lab", "Blueprint"]
    cols = st.columns(len(stages))
    for idx, (col, name) in enumerate(zip(cols, stages), 1):
        with col:
            if idx < current_stage_num:
                st.markdown(f"✅ **{idx}. {name}**")
            elif idx == current_stage_num:
                st.markdown(f"🔵 **{idx}. {name}**")
            else:
                st.markdown(f"⚪ *{idx}. {name}*")
    st.progress(current_stage_num / len(stages))
    st.markdown("---")


# ==============================================================================
# PAGE 1: RESEARCH INPUT & DIRECTOR
# ==============================================================================
if page.startswith("1."):
    render_workflow_progress(1)
    
    st.markdown("""
    <div class="main-header">
        <h1>ResearchPilot AI</h1>
        <p>An Autonomous Multi-Agent Research Workflow Assistant for Undergraduates, MSc/PhDs, and Scientists.</p>
    </div>
    """, unsafe_allow_html=True)
    
    col_input, col_info = st.columns([2, 1])
    
    with col_input:
        st.subheader("💡 Define Your Research Inquiry")
        
        exemplar_prompts = [
            "Deep Learning for Real-Time Plant Disease Detection in Resource-Constrained Edge IoT",
            "Harmonic Mitigation and Voltage Regulation in High-Penetration Photovoltaic Microgrids",
            "Targeted CRISPR-Cas9 Off-Target Cleavage Prediction and Differential Gene Expression Profiling",
            "Custom Research Idea..."
        ]
        
        selected_example = st.selectbox("Choose a Benchmark Template or Enter Your Own:", exemplar_prompts)
        
        if selected_example == "Custom Research Idea...":
            topic_input = st.text_area(
                "Enter Research Idea / Scientific Problem:",
                placeholder="e.g., Autonomous multi-agent coordination for urban wildfire monitoring using drone swarms...",
                height=130
            )
        else:
            topic_input = st.text_area(
                "Research Idea / Scientific Problem:",
                value=selected_example,
                height=110
            )
        
        launch_col1, launch_col2 = st.columns([1, 1])
        with launch_col1:
            run_btn = st.button("🚀 Launch Autonomous Research Team", type="primary", use_container_width=True)
        with launch_col2:
            single_step_btn = st.button("🔍 Analyze Topic Only (Step 1)", use_container_width=True)
        
        if run_btn and topic_input.strip():
            with st.status("🤖 Multi-Agent Research Director Orchestrating...", expanded=True) as status:
                st.write("Initializing Research Director and Domain Plugins...")
                llm = get_llm_service(
                    provider=llm_provider,
                    api_key=custom_api_key if custom_api_key else None
                )
                director = ResearchDirectorAgent(llm_service=llm)
                
                pref = None if domain_choice == "auto" else domain_choice
                
                # Execute full workflow with live telemetry
                state = ResearchWorkflowState(topic=topic_input, domain_preference=pref)
                
                st.write("1/5: 🧠 Topic Understanding Agent parsing keywords & challenges...")
                state = director.run_topic_understanding(state)
                
                st.write("2/5: 📚 Literature Intelligence Agent querying arXiv & Semantic Scholar...")
                state = director.run_literature_discovery(state)
                
                st.write("3/5: 🔍 Research Gap Agent identifying whitespaces & novelty...")
                state = director.run_gap_analysis(state)
                
                st.write("4/5: ⚙️ Methodology Agent engineering experimental design...")
                state = director.run_methodology_design(state)
                
                st.write("5/5: 📄 Report Generator Agent synthesizing research proposal blueprint...")
                state = director.run_report_generation(state)
                
                st.session_state.workflow_state = state
                status.update(label="✅ Research Blueprint Created Successfully!", state="complete", expanded=False)
            
            st.success("🎉 Full research blueprint generated! Navigate through the tabs or inspect the results below.")
            st.rerun()

    with col_info:
        st.subheader("🏛️ Architecture Overview")
        st.markdown("""
        **Domain-Agnostic Core + Plugin System**
        - **Director Agent**: Project manager orchestrating the workflow.
        - **Topic Agent**: Scientific taxonomy & keyword mining.
        - **Literature Agent**: arXiv & Semantic Scholar discovery.
        - **Gap Agent**: White-space & limitation synthesis.
        - **Methodology Agent**: Empirical study design.
        - **Data Agent**: Statistics & ML profiling.
        - **Report Agent**: LaTeX & Markdown blueprint synthesis.
        """)
        
        st.info("💡 **Tip**: Running with Mock Engine executes instantly offline without needing API keys.")

    # Show active workflow summary if available
    if st.session_state.workflow_state:
        state = st.session_state.workflow_state
        st.markdown("---")
        st.subheader(f"📋 Active Project: {state.topic}")
        
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Domain", state.topic_analysis.domain if state.topic_analysis else "N/A")
        m2.metric("Papers Surveyed", len(state.literature.papers) if state.literature else 0)
        m3.metric("Identified Gaps", len(state.gap_analysis.possible_contributions) if state.gap_analysis else 0)
        m4.metric("Status", "Blueprint Ready" if state.is_completed else state.current_step)
        
        if state.logs:
            with st.expander("📜 Agent Orchestration Execution Telemetry"):
                for log in state.logs:
                    st.text(log)


# ==============================================================================
# PAGE 2: LITERATURE EXPLORER & RAG
# ==============================================================================
elif page.startswith("2."):
    render_workflow_progress(2)
    st.header("📚 Literature Intelligence & Scientific RAG Explorer")
    
    state = st.session_state.workflow_state
    
    col_papers, col_rag = st.columns([3, 2])
    
    with col_papers:
        st.subheader("Surveyed Scientific Literature")
        
        # Search query controls
        search_query = st.text_input(
            "Search Live Academic Literature (arXiv & Semantic Scholar):",
            value=state.topic if state else "plant disease detection convolutional neural networks"
        )
        if st.button("Search Papers"):
            with st.spinner("Querying arXiv & Semantic Scholar..."):
                searcher = PaperSearchService()
                papers = searcher.search(search_query, max_results=6)
                if state:
                    state.literature.papers = papers
                st.session_state.custom_papers = papers
        
        papers_to_show = []
        if state and state.literature:
            papers_to_show = state.literature.papers
        elif "custom_papers" in st.session_state:
            papers_to_show = st.session_state.custom_papers
        else:
            searcher = PaperSearchService()
            papers_to_show = searcher.search(search_query, max_results=4)
        
        for i, paper in enumerate(papers_to_show, 1):
            with st.expander(f"📄 [{paper.source}] {paper.title} ({paper.year})", expanded=(i == 1)):
                st.markdown(f"**Authors**: {', '.join(paper.authors[:4])}")
                st.markdown(f"**Abstract**: {paper.abstract[:280]}...")
                
                c1, c2 = st.columns(2)
                with c1:
                    st.markdown(f"🛠️ **Method**: {paper.method}")
                    st.markdown(f"💾 **Dataset**: {paper.dataset}")
                with c2:
                    st.markdown(f"✨ **Finding**: {paper.finding}")
                    st.markdown(f"⚠️ **Limitation**: {paper.limitation}")
                
                st.markdown(f"🔮 **Future Direction**: {paper.future_direction}")
                if paper.url:
                    st.markdown(f"[🔗 View Original Publication Source]({paper.url})")

    with col_rag:
        st.subheader("🤖 Scientific RAG QA Assistant")
        st.markdown("*Answers questions strictly grounded in surveyed paper context.*")
        
        default_rag_q = "According to previous studies, what methods are commonly used?"
        rag_input = st.text_input("Ask about prior research:", value=default_rag_q)
        
        if st.button("Ask RAG Assistant", type="primary"):
            with st.spinner("Retrieving literature context & synthesizing answer..."):
                retriever = st.session_state.retriever
                # Ingest current papers into vector store if not yet indexed
                if papers_to_show and len(st.session_state.vector_store.chunks) == 0:
                    for p in papers_to_show:
                        chunks = st.session_state.doc_processor.chunk_document(
                            f"{p.title}\n{p.abstract}\nMethod: {p.method}\nFinding: {p.finding}\nLimitation: {p.limitation}",
                            doc_id=p.paper_id,
                            source_title=p.title
                        )
                        st.session_state.vector_store.add_chunks(chunks)
                
                qa_res = retriever.query(rag_input, top_k=3)
                
                st.markdown("#### Grounded Synthesis:")
                st.markdown(qa_res["answer"])
                
                if qa_res["sources"]:
                    st.markdown("##### Referenced Citations:")
                    for s in qa_res["sources"]:
                        st.caption(f"{s['ref']} **{s['source']}** ({s['section']}, Score: {s['score']}): *{s['snippet']}*")

        st.divider()
        st.subheader("📥 Ingest PDF Research Paper")
        uploaded_pdf = st.file_uploader("Upload custom PDF paper:", type=["pdf", "txt"])
        if uploaded_pdf and st.button("Process & Index Document"):
            with st.spinner("Extracting text and chunking semantic sections..."):
                temp_path = settings.PAPERS_DIR / uploaded_pdf.name
                temp_path.write_bytes(uploaded_pdf.read())
                chunks = st.session_state.doc_processor.process_file(temp_path)
                added = st.session_state.vector_store.add_chunks(chunks)
                st.success(f"Indexed {added} semantic chunks from '{uploaded_pdf.name}' into RAG vector store!")


# ==============================================================================
# PAGE 3: RESEARCH GAP MATRIX
# ==============================================================================
elif page.startswith("3."):
    render_workflow_progress(3)
    st.header("🔍 Research Gap Identification & White-Space Matrix")
    
    state = st.session_state.workflow_state
    
    if not state or not state.gap_analysis:
        st.warning("⚠️ No active research workflow detected. Please run Stage 1 or initialize with the button below.")
        if st.button("Generate Demo Gap Analysis"):
            llm = get_llm_service(provider=llm_provider)
            director = ResearchDirectorAgent(llm_service=llm)
            st.session_state.workflow_state = director.execute_full_workflow(
                "AI for Edge Plant Disease Diagnosis in Low-Power Nodes",
                domain_preference="cse"
            )
            st.rerun()
    else:
        gap = state.gap_analysis
        
        st.markdown(f"""
        <div class="highlight-banner">
            <h4 style="margin:0; color:#1e40af;">🎯 Primary Scientific Bottleneck</h4>
            <p style="margin:6px 0 0 0; color:#1e293b; font-size:1.05rem;">{gap.primary_gap_statement}</p>
        </div>
        """, unsafe_allow_html=True)
        
        c_exist, c_limit, c_white = st.columns(3)
        
        with c_exist:
            st.subheader("1. Existing Approaches")
            for item in gap.existing_approaches:
                st.markdown(f"""
                <div class="card-box">
                    <strong>{item.approach}</strong>
                    <p style="color:#64748b; font-size:0.9rem; margin-top:4px;">{item.description}</p>
                </div>
                """, unsafe_allow_html=True)
        
        with c_limit:
            st.subheader("2. Common Limitations")
            for lim in gap.common_limitations:
                st.markdown(f"""
                <div class="card-box" style="border-left: 4px solid #ef4444;">
                    <p style="margin:0; font-size:0.92rem;">⚠️ {lim}</p>
                </div>
                """, unsafe_allow_html=True)
        
        with c_white:
            st.subheader("3. Missing Whitespaces")
            for miss in gap.missing_areas:
                st.markdown(f"""
                <div class="card-box" style="border-left: 4px solid #f59e0b;">
                    <p style="margin:0; font-size:0.92rem;">🔬 {miss}</p>
                </div>
                """, unsafe_allow_html=True)

        st.subheader("✨ High-Impact Research Contribution Opportunities")
        for i, opp in enumerate(gap.possible_contributions, 1):
            st.markdown(f"""
            <div class="card-box" style="border-left: 4px solid #10b981;">
                <h4 style="margin:0; color:#065f46;">Opportunity {i}: {opp.title}</h4>
                <p style="margin:8px 0; font-size:0.95rem; color:#1f2937;">{opp.opportunity}</p>
                <span style="background:#d1fae5; color:#065f46; padding:2px 8px; border-radius:12px; font-size:0.8rem; font-weight:600;">
                    Potential Impact: {opp.potential_impact}
                </span>
            </div>
            """, unsafe_allow_html=True)


# ==============================================================================
# PAGE 4: METHODOLOGY DESIGNER
# ==============================================================================
elif page.startswith("4."):
    render_workflow_progress(4)
    st.header("⚙️ Experimental & Computational Methodology Designer")
    
    state = st.session_state.workflow_state
    
    if not state or not state.methodology:
        st.info("Execute Stage 1 to generate a methodology protocol, or inspect the interactive domain tools below.")
    else:
        meth = state.methodology
        
        col_m1, col_m2 = st.columns([3, 2])
        
        with col_m1:
            st.subheader("Experimental Pipeline Architecture")
            st.markdown(f"**Study Classification**: `{meth.study_type}`")
            st.markdown(f"**Validation Protocol**: `{meth.validation_protocol}`")
            st.markdown(f"**Computational Resources**: `{meth.compute_and_resources}`")
            
            st.markdown("#### Pipeline Execution Stages:")
            for step in meth.pipeline_stages:
                st.markdown(f"➡️ **{step}**")
            
            st.markdown("#### Recommended Benchmark Models:")
            for bm in meth.baselines_and_models:
                st.markdown(f"- `{bm}`")

        with col_m2:
            st.subheader("Domain Evaluation Metrics")
            for metric in meth.evaluation_metrics:
                st.markdown(f"""
                <div class="card-box">
                    <strong>{metric.name}</strong> (Target: <code>{metric.target_threshold}</code>)
                    <p style="color:#64748b; font-size:0.88rem; margin:4px 0 0 0;">{metric.rationale}</p>
                </div>
                """, unsafe_allow_html=True)
            
            st.markdown("#### Reproducibility Protocols:")
            for item in meth.reproducibility_checklist:
                st.markdown(f"✅ *{item}*")

    st.divider()
    st.subheader("🧮 Interactive Scientific Domain Calculators")
    
    tool_tab1, tool_tab2, tool_tab3 = st.tabs([
        "CSE: Train/Val/Test Split Calculator",
        "EEE: IEEE 519 Harmonic Evaluator",
        "Genetics: RNA-Seq Power Calculator"
    ])
    
    with tool_tab1:
        cse_plugin = PluginRegistry.get("cse")
        s_count = st.number_input("Sample Count (N):", min_value=50, max_value=500000, value=1200)
        is_imb = st.checkbox("Class Imbalance Present?")
        if st.button("Calculate Optimal Validation Strategy"):
            res = cse_plugin.execute_domain_tool("complexity_estimator", n_samples=s_count, is_imbalanced=is_imb)
            st.json(res)
    
    with tool_tab2:
        eee_plugin = PluginRegistry.get("eee")
        v_kv = st.number_input("Nominal Voltage (kV):", min_value=0.1, max_value=500.0, value=0.4)
        thd_val = st.number_input("Simulated / Measured THD (%):", min_value=0.1, max_value=25.0, value=4.2)
        if st.button("Check IEEE 519 Standard Compliance"):
            res = eee_plugin.execute_domain_tool("thd_compliance_checker", voltage_kv=v_kv, thd_percent=thd_val)
            if res["is_compliant"]:
                st.success(f"✅ Compliant with IEEE 519 limit of {res['ieee519_limit_percent']}%!")
            else:
                st.error(f"❌ Non-Compliant! Limit is {res['ieee519_limit_percent']}%. {res['recommendation']}")
            st.json(res)
            
    with tool_tab3:
        gen_plugin = PluginRegistry.get("genetics")
        reps = st.slider("Biological Replicates (n):", min_value=2, max_value=12, value=3)
        fc_target = st.number_input("Target Fold Change:", min_value=1.1, max_value=10.0, value=2.0)
        if st.button("Compute Replicate Statistical Power"):
            res = gen_plugin.execute_domain_tool("sample_power_calculator", n_replicates=reps, target_fc=fc_target)
            st.json(res)


# ==============================================================================
# PAGE 5: DATA ANALYSIS LAB
# ==============================================================================
elif page.startswith("5."):
    render_workflow_progress(5)
    st.header("📊 Empirical Data Analysis & Machine Learning Lab")
    
    st.markdown("""
    <div class="disclaimer-box">
        <strong>⚠️ Scientific Disclaimer:</strong> Generated and demo datasets are provided solely for workflow demonstration and architectural validation.
        They should never replace empirical physical laboratory experiments or field trial data.
    </div>
    """, unsafe_allow_html=True)
    
    data_source = st.radio(
        "Select Data Source:",
        [
            "Use Sample Scientific Dataset",
            "Upload Custom CSV File"
        ],
        horizontal=True
    )
    
    df: Optional[pd.DataFrame] = None
    dataset_name = ""
    
    if data_source == "Use Sample Scientific Dataset":
        demo_choice = st.selectbox(
            "Choose Demonstration Dataset:",
            [
                "CSE: Edge IoT Fault Sensor Classification (cse_edge_faults.csv)",
                "EEE: Microgrid Voltage & Stability Regression (eee_grid_stability.csv)",
                "Genetics: Differential Gene Expression RNA-Seq (genetics_rna_diff_expr.csv)"
            ]
        )
        if "cse" in demo_choice:
            path = settings.DATASETS_DIR / "cse_edge_faults.csv"
            dataset_name = "CSE Edge IoT Fault Classification"
        elif "eee" in demo_choice:
            path = settings.DATASETS_DIR / "eee_grid_stability.csv"
            dataset_name = "EEE Microgrid Voltage & Stability Simulation"
        else:
            path = settings.DATASETS_DIR / "genetics_rna_diff_expr.csv"
            dataset_name = "Genetics RNA-Seq Differential Expression"
            
        if path.exists():
            df = pd.read_csv(path)
            st.session_state.current_df = df
            st.session_state.current_df_name = dataset_name
    else:
        uploaded_csv = st.file_uploader("Upload CSV Data File:", type=["csv"])
        if uploaded_csv:
            df = pd.read_csv(uploaded_csv)
            dataset_name = uploaded_csv.name
            st.session_state.current_df = df
            st.session_state.current_df_name = dataset_name
            
    if df is not None:
        st.subheader(f"📋 Dataset Overview: {dataset_name} ({len(df)} rows, {len(df.columns)} columns)")
        st.dataframe(df.head(6), use_container_width=True)
        
        tab_stats, tab_plots, tab_ml = st.tabs([
            "📈 Descriptive Statistics & Correlation",
            "📊 Scientific Visualizations",
            "🤖 Automated ML Baselines & Interpretation"
        ])
        
        with tab_stats:
            stats = compute_descriptive_statistics(df)
            corr = compute_correlation_matrix(df)
            
            c_s1, c_s2 = st.columns([3, 2])
            with c_s1:
                st.markdown("#### Parametric & Non-Parametric Metrics:")
                df_stats = pd.DataFrame(stats["statistics"]).T
                st.dataframe(df_stats[["mean", "std", "median", "iqr", "skewness", "kurtosis", "is_approximately_normal"]], use_container_width=True)
            
            with c_s2:
                st.markdown("#### Dominant Feature Correlations:")
                if corr.get("top_correlated_pairs"):
                    st.dataframe(pd.DataFrame(corr["top_correlated_pairs"])[["feature_1", "feature_2", "correlation", "relationship"]], use_container_width=True)
                else:
                    st.info("No numeric correlation pairs found.")

        with tab_plots:
            col_p1, col_p2 = st.columns(2)
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            
            with col_p1:
                if numeric_cols:
                    dist_col = st.selectbox("Select Feature for Distribution Plot:", numeric_cols, index=0)
                    st.plotly_chart(create_distribution_plot(df, dist_col), use_container_width=True)
                    
            with col_p2:
                if len(numeric_cols) >= 2:
                    st.plotly_chart(create_correlation_heatmap(df), use_container_width=True)
            
            # Specialized Bivariate / Volcano Plot
            if "log2_fold_change" in df.columns and "padj_fdr" in df.columns:
                st.markdown("#### Genomic Differential Expression Volcano Plot:")
                st.plotly_chart(create_volcano_plot(df), use_container_width=True)
            elif len(numeric_cols) >= 2:
                st.markdown("#### Bivariate Empirical Relationship:")
                x_sel = numeric_cols[0]
                y_sel = numeric_cols[1]
                cat_cols = df.select_dtypes(include=["object"]).columns.tolist()
                c_sel = cat_cols[0] if cat_cols else None
                st.plotly_chart(create_scatter_plot(df, x_sel, y_sel, color_col=c_sel), use_container_width=True)

        with tab_ml:
            st.markdown("#### Train Automated Machine Learning Baselines")
            
            c_tgt1, c_tgt2 = st.columns(2)
            with c_tgt1:
                target_col = st.selectbox("Select Target Variable to Predict:", df.columns.tolist(), index=len(df.columns)-1)
            with c_tgt2:
                task_mode = st.radio("Task Type:", ["Auto-Detect", "Classification", "Regression"], horizontal=True)
                
            if st.button("🚀 Train Machine Learning Models & Generate Interpretation", type="primary"):
                with st.spinner("Fitting models, evaluating metrics, and generating scientific interpretation..."):
                    llm = get_llm_service(provider=llm_provider)
                    data_agent = DataAnalysisAgent(llm_service=llm)
                    
                    real_mode = None if task_mode == "Auto-Detect" else task_mode
                    report = data_agent.analyze_dataset(
                        df,
                        dataset_name=dataset_name,
                        target_column=target_col,
                        task_type=real_mode
                    )
                    st.session_state.analysis_report = report
                    
            if st.session_state.analysis_report:
                rep = st.session_state.analysis_report
                
                if rep.ml_benchmark and "benchmark_results" in rep.ml_benchmark:
                    ml_data = rep.ml_benchmark
                    st.success(f"Best Model: **{ml_data.get('best_model')}** ({ml_data.get('task_type')})")
                    
                    st.dataframe(pd.DataFrame(ml_data["benchmark_results"]), use_container_width=True)
                    
                    if ml_data.get("feature_importances"):
                        st.markdown("#### Predictive Feature Importance:")
                        f_names = [item["feature"] for item in ml_data["feature_importances"]]
                        f_weights = [item["importance"] for item in ml_data["feature_importances"]]
                        st.plotly_chart(create_feature_importance_plot(f_names, f_weights), use_container_width=True)

                st.markdown("### 📝 Scientific Interpretation & Discussion")
                st.markdown(f"""
                <div class="card-box">
                    {rep.scientific_interpretation}
                </div>
                """, unsafe_allow_html=True)


# ==============================================================================
# PAGE 6: FINAL BLUEPRINT & EXPORT
# ==============================================================================
elif page.startswith("6."):
    render_workflow_progress(6)
    st.header("📄 Final Research Blueprint & Publication Export")
    
    state = st.session_state.workflow_state
    
    if not state or not state.report:
        st.warning("⚠️ No completed research blueprint found. Please execute the workflow in Stage 1.")
        if st.button("Generate Demo Research Blueprint"):
            llm = get_llm_service(provider=llm_provider)
            director = ResearchDirectorAgent(llm_service=llm)
            st.session_state.workflow_state = director.execute_full_workflow(
                "Deep Learning for Real-Time Plant Disease Detection in Complex Field Environments",
                domain_preference="cse"
            )
            st.rerun()
    else:
        report = state.report
        
        st.markdown(f"## {report.title}")
        st.caption(f"Domain: {state.topic_analysis.domain} | Framework: ResearchPilot AI Autonomous Blueprint")
        
        # Download Action Bar
        col_dl1, col_dl2, col_dl3 = st.columns([1, 1, 2])
        with col_dl1:
            st.download_button(
                label="📥 Download Markdown (.md)",
                data=report.markdown_content,
                file_name=f"{state.workflow_id}_research_blueprint.md",
                mime="text/markdown",
                use_container_width=True
            )
        with col_dl2:
            st.download_button(
                label="📑 Download LaTeX (.tex)",
                data=report.latex_content,
                file_name=f"{state.workflow_id}_manuscript.tex",
                mime="text/x-tex",
                use_container_width=True
            )
            
        st.divider()
        
        tab_rendered, tab_md_raw, tab_tex_raw = st.tabs([
            "📖 Formatted Proposal Document",
            "📝 Raw Markdown",
            "📐 Raw LaTeX Source"
        ])
        
        with tab_rendered:
            st.markdown(report.markdown_content)
            
        with tab_md_raw:
            st.code(report.markdown_content, language="markdown")
            
        with tab_tex_raw:
            st.code(report.latex_content, language="latex")
