"""
ResearchPilot AI Backend Application.
"""
