"""
Data Analysis Agent.

Executes descriptive statistics, feature correlation matrices, and machine learning models,
translating empirical metrics into scholarly scientific interpretations.
"""

from typing import Dict, Any, List, Optional
import pandas as pd
from pydantic import BaseModel, Field
import logging

from analysis.statistics import compute_descriptive_statistics, compute_correlation_matrix
from analysis.ml_models import train_classification_models, train_regression_models
from backend.services.llm_service import BaseLLMClient, get_llm_service

logger = logging.getLogger(__name__)


class EmpiricalAnalysisReport(BaseModel):
    """Complete scientific data profiling and interpretation report."""
    dataset_name: str
    row_count: int
    column_count: int
    statistics_summary: Dict[str, Any]
    correlation_findings: Dict[str, Any]
    ml_benchmark: Optional[Dict[str, Any]] = None
    scientific_interpretation: str = Field(description="Scholarly narrative interpreting the empirical patterns")
    experimental_caveat: str = (
        "CRITICAL NOTICE: Generated/demo data should not replace real experiments. "
        "Findings should be verified using empirical physical laboratory instrumentation or curated real-world field trials."
    )


class DataAnalysisAgent:
    """Agent that performs statistical analytics and scientific narrative generation."""

    def __init__(self, llm_service: Optional[BaseLLMClient] = None):
        self.llm = llm_service or get_llm_service()

    def analyze_dataset(
        self,
        df: pd.DataFrame,
        dataset_name: str = "Uploaded Research Dataset",
        target_column: Optional[str] = None,
        task_type: Optional[str] = None
    ) -> EmpiricalAnalysisReport:
        """Run statistical profiling, train ML baselines if applicable, and synthesize interpretation."""
        stats = compute_descriptive_statistics(df)
        corr = compute_correlation_matrix(df)

        # Automatic or explicit ML training
        ml_results = None
        if target_column and target_column in df.columns:
            if task_type == "Classification" or (
                task_type is None and df[target_column].nunique() < 10 and not pd.api.types.is_float_dtype(df[target_column])
            ):
                ml_results = train_classification_models(df, target_col=target_column)
            else:
                ml_results = train_regression_models(df, target_col=target_column)
        elif len(df.columns) >= 3:
            # Auto-detect target: pick last numeric column as regression or last column as classification
            last_col = df.columns[-1]
            if df[last_col].nunique() < 10:
                ml_results = train_classification_models(df, target_col=last_col)
            else:
                ml_results = train_regression_models(df, target_col=last_col)

        # Generate scientific narrative
        interpretation = self._generate_scientific_interpretation(df, dataset_name, stats, corr, ml_results)

        return EmpiricalAnalysisReport(
            dataset_name=dataset_name,
            row_count=len(df),
            column_count=len(df.columns),
            statistics_summary=stats,
            correlation_findings=corr,
            ml_benchmark=ml_results,
            scientific_interpretation=interpretation
        )

    def _generate_scientific_interpretation(
        self,
        df: pd.DataFrame,
        name: str,
        stats: Dict[str, Any],
        corr: Dict[str, Any],
        ml_results: Optional[Dict[str, Any]]
    ) -> str:
        """Produce academic prose synthesizing empirical data distributions and predictive patterns."""
        top_corrs = corr.get("top_correlated_pairs", [])[:4]
        corr_summary = ", ".join([
            f"{p['feature_1']} <-> {p['feature_2']} (r = {p['correlation']})"
            for p in top_corrs
        ]) if top_corrs else "No dominant linear correlations detected."

        ml_summary = "No predictive models were trained on this data."
        if ml_results and "benchmark_results" in ml_results:
            b_model = ml_results.get("best_model", "Standard Baseline")
            benchmarks = [
                f"{b['model']}: {b.get('f1_score', b.get('r2_score', 'N/A'))}"
                for b in ml_results.get("benchmark_results", [])
            ]
            importances = [
                f"{item['feature']} ({item['importance']})"
                for item in ml_results.get("feature_importances", [])[:3]
            ]
            ml_summary = (
                f"Task: {ml_results.get('task_type')}. Best Model: {b_model}. "
                f"Performance summary: {', '.join(benchmarks)}. "
                f"Top influential features: {', '.join(importances)}."
            )

        prompt = f"""
You are the Data Analysis Agent in ResearchPilot AI.
Draft a rigorous 3-paragraph scientific interpretation section for a research paper report based on this empirical analysis:

DATASET: "{name}" ({len(df)} observations, {len(df.columns)} features)
KEY CORRELATIONS:
{corr_summary}

PREDICTIVE BENCHMARK RESULTS:
{ml_summary}

STRUCTURE YOUR RESPONSE:
Paragraph 1: Distributional characteristics and statistical variance across key variables.
Paragraph 2: Correlation structure, dominant covariance patterns, and physical/biological implications.
Paragraph 3: Predictive modeling evaluation, primary feature attribution, and methodological takeaways.
Maintain an objective, scholarly tone.
"""
        system_prompt = (
            "You are a computational statistician and data scientist writing the Results section of an academic manuscript."
        )

        return self.llm.generate_text(prompt, system_prompt=system_prompt)
