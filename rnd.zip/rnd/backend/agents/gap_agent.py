"""
Research Gap Agent.

Analyzes literature to pinpoint methodological deficiencies, unaddressed variables, and novel contribution opportunities.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
import logging

from backend.services.llm_service import BaseLLMClient, get_llm_service
from backend.agents.topic_agent import TopicAnalysis
from backend.agents.literature_agent import LiteratureCorpus
from domains.base import PluginRegistry

logger = logging.getLogger(__name__)


class ExistingApproach(BaseModel):
    approach: str
    description: str


class ContributionOpportunity(BaseModel):
    title: str
    opportunity: str
    potential_impact: str = "High"


class ResearchGapAnalysis(BaseModel):
    """Structured research gap analysis."""
    topic: str
    existing_approaches: List[ExistingApproach] = Field(default_factory=list)
    common_limitations: List[str] = Field(default_factory=list)
    missing_areas: List[str] = Field(default_factory=list)
    possible_contributions: List[ContributionOpportunity] = Field(default_factory=list)
    primary_gap_statement: str = Field(default="", description="Crisp one-sentence summary of the core scientific bottleneck")


class ResearchGapAgent:
    """Agent that identifies unexplored whitespaces and articulates research gaps."""

    def __init__(self, llm_service: Optional[BaseLLMClient] = None):
        self.llm = llm_service or get_llm_service()

    def identify_gaps(
        self,
        topic_analysis: TopicAnalysis,
        literature: LiteratureCorpus
    ) -> ResearchGapAnalysis:
        """Analyze literature to discover high-value research gaps and opportunities."""
        plugin = PluginRegistry.get(topic_analysis.domain_key)
        domain_prompt = plugin.get_system_prompt_enhancements() if plugin else ""

        # Extract paper limitations
        limitations_summary = "\n".join([
            f"- Paper: '{p.title}' | Method: {p.method} | Limitation: {p.limitation} | Future: {p.future_direction}"
            for p in literature.papers
        ])

        prompt = f"""
You are the Research Gap Agent in ResearchPilot AI.
Analyze the following research topic, existing methods, and surveyed literature limitations to identify critical research gaps and high-impact contribution opportunities.

TOPIC: "{topic_analysis.topic}"
DOMAIN: "{topic_analysis.domain}"

SURVEYED LITERATURE & LIMITATIONS:
{limitations_summary if limitations_summary else "General benchmark models lack real-time validation and robustness under distribution shifts."}

Return a JSON object with this exact structure:
{{
  "existing_approaches": [
    {{"approach": "Name of Existing Approach 1", "description": "Brief description of how it works"}},
    {{"approach": "Name of Existing Approach 2", "description": "Brief description of how it works"}}
  ],
  "common_limitations": [
    "Limitation 1: Specific drawback observed across literature",
    "Limitation 2: Validation bottleneck or missing parameter",
    "Limitation 3: Deployment or computational constraint"
  ],
  "missing_areas": [
    "Unaddressed scientific whitespace 1",
    "Unaddressed scientific whitespace 2"
  ],
  "possible_contributions": [
    {{
      "title": "Novel Contribution 1",
      "opportunity": "Specific innovative methodology or experimental validation to bridge the gap",
      "potential_impact": "High"
    }},
    {{
      "title": "Novel Contribution 2",
      "opportunity": "Specific innovative methodology or experimental validation to bridge the gap",
      "potential_impact": "High"
    }}
  ],
  "primary_gap_statement": "Concise 1-2 sentence articulation of the central scientific whitespace this research addresses."
}}
"""
        system_prompt = (
            "You are a member of an academic doctoral thesis committee specializing in identifying research novelty."
            f"\n{domain_prompt}"
        )

        try:
            resp = self.llm.generate_json(prompt, system_prompt=system_prompt)
            existing_approaches = [
                ExistingApproach(**item) if isinstance(item, dict) else ExistingApproach(approach=str(item), description="")
                for item in resp.get("existing_approaches", [])
            ]
            possible_contributions = [
                ContributionOpportunity(**item) if isinstance(item, dict) else ContributionOpportunity(title=str(item), opportunity="")
                for item in resp.get("possible_contributions", [])
            ]

            primary_gap = resp.get("primary_gap_statement") or (
                f"While existing studies in {topic_analysis.domain} have demonstrated strong baseline results, "
                f"there remains a critical gap in real-world validation, efficiency trade-offs, and empirical robustness."
            )

            return ResearchGapAnalysis(
                topic=topic_analysis.topic,
                existing_approaches=existing_approaches or [
                    ExistingApproach(approach="Standard Monolithic Architectures", description="Deep learning baselines evaluated on static datasets.")
                ],
                common_limitations=resp.get("common_limitations", [
                    "High sensitivity to unseen environmental variations",
                    "Lack of resource-constrained deployment testing"
                ]),
                missing_areas=resp.get("missing_areas", [
                    "Empirical validation under real-time sensor streams",
                    "Ablation studies examining minimal sufficient parameter sets"
                ]),
                possible_contributions=possible_contributions or [
                    ContributionOpportunity(
                        title="Adaptive Multi-Modal Empirical Framework",
                        opportunity="Combines lightweight domain-constrained modeling with real-time feedback."
                    )
                ],
                primary_gap_statement=primary_gap
            )
        except Exception as e:
            logger.error(f"Gap agent analysis error: {e}. Returning robust fallback.")
            return ResearchGapAnalysis(
                topic=topic_analysis.topic,
                existing_approaches=[
                    ExistingApproach(approach="Baseline Deep Learning", description="Standard convolutional or transformer pipelines.")
                ],
                common_limitations=["Limited out-of-distribution validation", "High inference computational cost"],
                missing_areas=["Integration with physical constraints", "Ablation of feature sets"],
                possible_contributions=[
                    ContributionOpportunity(
                        title="Hybrid Domain-Aware Inference Architecture",
                        opportunity="Infuses domain metrics into training loss to boost generalizability."
                    )
                ],
                primary_gap_statement="A critical gap exists in validating predictive accuracy under resource-constrained and real-world noisy conditions."
            )
