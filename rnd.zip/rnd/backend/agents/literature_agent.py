"""
Literature Intelligence Agent.

Discovers peer-reviewed literature across arXiv and Semantic Scholar, extracting methods, findings, and limits.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
import logging

from backend.services.paper_search import PaperSearchService, ScientificPaper
from backend.services.llm_service import BaseLLMClient, get_llm_service
from backend.agents.topic_agent import TopicAnalysis

logger = logging.getLogger(__name__)


class LiteratureCorpus(BaseModel):
    """Structured literature intelligence corpus."""
    query_used: str
    total_found: int
    papers: List[ScientificPaper] = Field(default_factory=list)
    synthesis_summary: str = Field(default="", description="High-level narrative synthesis of surveyed papers")
    dominant_methods: List[str] = Field(default_factory=list)
    prominent_datasets: List[str] = Field(default_factory=list)


class LiteratureIntelligenceAgent:
    """Agent responsible for automated scientific literature discovery and analysis."""

    def __init__(
        self,
        paper_search_service: Optional[PaperSearchService] = None,
        llm_service: Optional[BaseLLMClient] = None
    ):
        self.search_service = paper_search_service or PaperSearchService()
        self.llm = llm_service or get_llm_service()

    def discover_literature(
        self,
        topic_analysis: TopicAnalysis,
        max_papers: int = 6
    ) -> LiteratureCorpus:
        """Search literature using extracted keywords and synthesize findings."""
        # Formulate query from topic and top keywords
        top_kws = " ".join(topic_analysis.keywords[:3]) if topic_analysis.keywords else ""
        query = f"{topic_analysis.topic} {top_kws}".strip()

        logger.info(f"Querying scientific literature with: '{query}'")
        papers = self.search_service.search(query, max_results=max_papers)

        # Extract dominant methods & datasets
        dominant_methods = list({p.method for p in papers if p.method})[:5]
        prominent_datasets = list({p.dataset for p in papers if p.dataset})[:5]

        # Generate narrative synthesis
        synthesis = self._synthesize_literature(topic_analysis.topic, papers)

        return LiteratureCorpus(
            query_used=query,
            total_found=len(papers),
            papers=papers,
            synthesis_summary=synthesis,
            dominant_methods=dominant_methods,
            prominent_datasets=prominent_datasets
        )

    def _synthesize_literature(self, topic: str, papers: List[ScientificPaper]) -> str:
        """Produce scientific synthesis of retrieved literature."""
        if not papers:
            return "No previous literature retrieved for this topic query."

        paper_briefs = []
        for i, p in enumerate(papers, 1):
            paper_briefs.append(
                f"{i}. \"{p.title}\" ({p.year}) by {', '.join(p.authors[:2])}: "
                f"Method=[{p.method}], Dataset=[{p.dataset}], Finding=[{p.finding}], Limitation=[{p.limitation}]"
            )

        prompt = f"""
You are the Literature Intelligence Agent in ResearchPilot AI.
Synthesize the state of the art based on these surveyed peer-reviewed papers for topic: "{topic}"

PAPERS:
{chr(10).join(paper_briefs)}

Generate a cohesive 2-3 paragraph scientific literature review synthesis covering:
1. Prevailing architectural paradigms and analytical methods.
2. Standard benchmark datasets commonly evaluated.
3. Emerging patterns in empirical findings across the studies.
Keep tone formal, objective, and scholarly.
"""
        return self.llm.generate_text(
            prompt,
            system_prompt="You are a senior academic reviewer synthesizing literature for a grant/proposal."
        )
