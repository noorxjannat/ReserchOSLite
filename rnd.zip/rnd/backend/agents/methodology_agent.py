"""
Methodology Agent.

Designs rigorous experimental, computational, or simulation study architectures.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
import logging

from backend.services.llm_service import BaseLLMClient, get_llm_service
from backend.agents.topic_agent import TopicAnalysis
from backend.agents.gap_agent import ResearchGapAnalysis
from domains.base import PluginRegistry

logger = logging.getLogger(__name__)


class EvaluationMetricRecommendation(BaseModel):
    name: str
    target_threshold: str
    rationale: str


class MethodologyBlueprint(BaseModel):
    """Structured scientific methodology recommendation."""
    study_type: str = Field(description="Experimental, Computational, Simulation, or Hybrid")
    pipeline_stages: List[str] = Field(default_factory=list)
    suggested_datasets: List[Dict[str, str]] = Field(default_factory=list)
    baselines_and_models: List[str] = Field(default_factory=list)
    evaluation_metrics: List[EvaluationMetricRecommendation] = Field(default_factory=list)
    validation_protocol: str = Field(default="5-Fold Stratified Cross-Validation with Paired t-tests")
    compute_and_resources: str = Field(default="Standard Workstation / GPU instance")
    reproducibility_checklist: List[str] = Field(default_factory=list)


class MethodologyAgent:
    """Agent that translates research gaps into actionable scientific study protocols."""

    def __init__(self, llm_service: Optional[BaseLLMClient] = None):
        self.llm = llm_service or get_llm_service()

    def design_methodology(
        self,
        topic_analysis: TopicAnalysis,
        gap_analysis: ResearchGapAnalysis
    ) -> MethodologyBlueprint:
        """Design scientific experimental protocol aligned with domain standards."""
        plugin = PluginRegistry.get(topic_analysis.domain_key)
        domain_prompt = plugin.get_system_prompt_enhancements() if plugin else ""
        domain_metrics = plugin.get_domain_metrics() if plugin else []

        metrics_hint = ", ".join([f"{m.name} ({m.symbol})" for m in domain_metrics]) if domain_metrics else "Accuracy, F1-Score, Latency"

        prompt = f"""
You are the Methodology Agent in ResearchPilot AI.
Design an experimental or computational research methodology for:

TOPIC: "{topic_analysis.topic}"
DOMAIN: "{topic_analysis.domain}"
PRIMARY GAP: "{gap_analysis.primary_gap_statement}"
PROPOSED NOVELTY: "{gap_analysis.possible_contributions[0].opportunity if gap_analysis.possible_contributions else 'Novel framework'}"

DOMAIN METRICS REFERENCE:
{metrics_hint}

Return a JSON object with this exact structure:
{{
  "study_type": "Computational and Empirical Simulation",
  "pipeline_stages": [
    "Stage 1: Data acquisition, cleaning, and train/test partition",
    "Stage 2: Feature extraction / preprocessing",
    "Stage 3: Baseline model implementation and hyperparameter tuning",
    "Stage 4: Proposed novel architecture execution",
    "Stage 5: Ablation study isolating key novel components",
    "Stage 6: Statistical significance testing (p < 0.05)"
  ],
  "suggested_datasets": [
    {{
      "name": "Dataset Name",
      "type": "Public Benchmark / Synthetic / Experimental",
      "description": "Characteristics, sample size, and target variables"
    }}
  ],
  "baselines_and_models": [
    "Baseline 1 (Classic)",
    "Baseline 2 (State-of-the-Art)",
    "Proposed Model / Algorithm"
  ],
  "evaluation_metrics": [
    {{"name": "Metric Name", "target_threshold": "> 90%", "rationale": "Why this metric is essential"}},
    {{"name": "Secondary Metric", "target_threshold": "benchmark", "rationale": "Scientific justification"}}
  ],
  "validation_protocol": "Detailed validation strategy (e.g., Stratified 10-fold cross-validation with Bonferroni correction)",
  "compute_and_resources": "Required compute hardware, simulation libraries, or laboratory equipment",
  "reproducibility_checklist": [
    "Fixed random seeds across all experiments",
    "Open-source codebase with environment manifest",
    "Ablation tables reporting mean and standard deviations across runs"
  ]
}}
"""
        system_prompt = (
            "You are a scientific methodologist designing an authoritative, reproducible experimental framework."
            f"\n{domain_prompt}"
        )

        try:
            resp = self.llm.generate_json(prompt, system_prompt=system_prompt)
            metrics_recs = [
                EvaluationMetricRecommendation(**m) if isinstance(m, dict) else EvaluationMetricRecommendation(name=str(m), target_threshold="SOTA", rationale="")
                for m in resp.get("evaluation_metrics", [])
            ]

            return MethodologyBlueprint(
                study_type=resp.get("study_type", "Computational & Empirical Simulation"),
                pipeline_stages=resp.get("pipeline_stages", [
                    "Stage 1: Data curation and stratified partitioning",
                    "Stage 2: Baseline architecture benchmark execution",
                    "Stage 3: Proposed novel algorithm integration",
                    "Stage 4: Rigorous cross-validation and ablation testing",
                    "Stage 5: Statistical significance verification (p < 0.05)"
                ]),
                suggested_datasets=resp.get("suggested_datasets", [
                    {"name": "Public Domain Benchmark", "type": "Open Access", "description": "Representative scientific dataset"}
                ]),
                baselines_and_models=resp.get("baselines_and_models", [
                    "Baseline 1: Standard Supervised Benchmark",
                    "Baseline 2: Contemporary State-of-the-Art",
                    "Proposed Method: ResearchPilot Adaptive Multi-Layer Model"
                ]),
                evaluation_metrics=metrics_recs or [
                    EvaluationMetricRecommendation(name="Accuracy / F1-Score", target_threshold="> 90%", rationale="Core predictive efficacy"),
                    EvaluationMetricRecommendation(name="Computational Efficiency", target_threshold="< 50 ms latency", rationale="Deployment feasibility")
                ],
                validation_protocol=resp.get("validation_protocol", "Stratified 5-Fold Cross-Validation with paired t-tests"),
                compute_and_resources=resp.get("compute_and_resources", "Standard GPU Workstation / Python scientific stack"),
                reproducibility_checklist=resp.get("reproducibility_checklist", [
                    "Fixed random seeds across all experimental runs",
                    "Standardized evaluation metrics aligned with domain guidelines",
                    "Publicly verifiable dataset splits and hyperparameter grid"
                ])
            )
        except Exception as e:
            logger.error(f"Methodology agent error: {e}. Returning robust blueprint.")
            return MethodologyBlueprint(
                study_type="Computational and Empirical Experimentation",
                pipeline_stages=[
                    "Stage 1: Data ingestion and stratified partitioning",
                    "Stage 2: Baseline model replication",
                    "Stage 3: Proposed model implementation",
                    "Stage 4: Component ablation analysis",
                    "Stage 5: Statistical hypothesis testing"
                ],
                suggested_datasets=[{"name": "Benchmark Dataset", "type": "Open Science", "description": "Curated feature matrix"}],
                baselines_and_models=["Linear/Heuristic Baseline", "Current SOTA", "Proposed Framework"],
                evaluation_metrics=[
                    EvaluationMetricRecommendation(name="Primary Metric", target_threshold="> 85%", rationale="Primary success criteria")
                ],
                validation_protocol="10-Fold Cross-Validation with Wilcoxon signed-rank test",
                compute_and_resources="Python 3.11+, PyTorch / Scikit-learn, Multi-core CPU",
                reproducibility_checklist=["Seeds fixed", "Code open-sourced", "Standard metrics"]
            )
