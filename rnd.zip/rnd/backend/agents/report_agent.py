"""
Report Generator Agent.

Synthesizes the complete research journey into a publication-grade research proposal blueprint.
Supports Markdown and LaTeX export formats.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
import logging

from backend.services.llm_service import BaseLLMClient, get_llm_service
from backend.agents.topic_agent import TopicAnalysis
from backend.agents.literature_agent import LiteratureCorpus
from backend.agents.gap_agent import ResearchGapAnalysis
from backend.agents.methodology_agent import MethodologyBlueprint

logger = logging.getLogger(__name__)


class ResearchReportBlueprint(BaseModel):
    """Complete publication-ready research blueprint document."""
    title: str
    abstract: str
    introduction_outline: List[str] = Field(default_factory=list)
    research_gaps: List[str] = Field(default_factory=list)
    research_questions: List[str] = Field(default_factory=list)
    hypotheses: List[str] = Field(default_factory=list)
    methodology_summary: str = Field(default="")
    expected_results: str = Field(default="")
    future_work: str = Field(default="")
    markdown_content: str = Field(default="")
    latex_content: str = Field(default="")


class ReportGeneratorAgent:
    """Agent that compiles structured research findings into formal research blueprints."""

    def __init__(self, llm_service: Optional[BaseLLMClient] = None):
        self.llm = llm_service or get_llm_service()

    def generate_report(
        self,
        topic_analysis: TopicAnalysis,
        literature: LiteratureCorpus,
        gap_analysis: ResearchGapAnalysis,
        methodology: MethodologyBlueprint
    ) -> ResearchReportBlueprint:
        """Synthesize all research stages into a comprehensive research proposal blueprint."""
        prompt = f"""
You are the Report Generator Agent in ResearchPilot AI.
Synthesize the following research stages into a formal research proposal blueprint:

TOPIC: "{topic_analysis.topic}"
DOMAIN: "{topic_analysis.domain}"
PRIMARY GAP: "{gap_analysis.primary_gap_statement}"
PROPOSED NOVELTY: "{gap_analysis.possible_contributions[0].opportunity if gap_analysis.possible_contributions else 'Hybrid adaptive framework'}"
STUDY TYPE: "{methodology.study_type}"
VALIDATION: "{methodology.validation_protocol}"

SURVEYED PAPERS:
{', '.join([p.title for p in literature.papers[:4]])}

Return a JSON object with this exact structure:
{{
  "title": "A formal, high-impact scholarly title for the research paper/proposal",
  "abstract": "A 200-250 word formal academic abstract covering Context, Problem, Method, Expected Contribution, and Significance.",
  "introduction_outline": [
    "1. Motivation and real-world significance of the research topic",
    "2. Overview of current state-of-the-art and foundational limitations",
    "3. Identification of the primary scientific bottleneck",
    "4. Statement of contributions and structural layout of the study"
  ],
  "research_gaps": [
    "Specific gap 1",
    "Specific gap 2"
  ],
  "research_questions": [
    "RQ1: Clear empirical question?",
    "RQ2: Clear theoretical/computational question?"
  ],
  "hypotheses": [
    "H1: Measurable, testable scientific hypothesis statement.",
    "H2: Measurable secondary hypothesis regarding computational efficiency."
  ],
  "methodology_summary": "Thorough summary of the proposed experimental design, datasets, models, and validation protocols.",
  "expected_results": "Anticipated findings, quantitative benchmark improvements, and theoretical implications.",
  "future_work": "Promising future research vectors, scalability directions, and cross-domain adaptations."
}}
"""
        system_prompt = (
            "You are an accomplished principal investigator and IEEE/ACM editor drafting a high-impact research proposal."
        )

        try:
            resp = self.llm.generate_json(prompt, system_prompt=system_prompt)
            title = resp.get("title", f"An Autonomous Empirical Investigation into {topic_analysis.topic}")
            abstract = resp.get("abstract", "This study formulates an autonomous research framework...")
            intro_outline = resp.get("introduction_outline", [
                "1. Scientific motivation and background",
                "2. Limitations of existing baseline approaches",
                "3. Formulation of the primary research whitespace",
                "4. Summary of contributions"
            ])
            r_gaps = resp.get("research_gaps", [gap_analysis.primary_gap_statement])
            rqs = resp.get("research_questions", [
                f"RQ1: To what extent does the proposed framework improve generalization in {topic_analysis.topic}?",
                "RQ2: What is the computational efficiency trade-off across real-world deployment settings?"
            ])
            hyps = resp.get("hypotheses", [
                "H1: The proposed method yields a statistically significant increase in predictive performance (p < 0.05).",
                "H2: Ablation variants will confirm the indispensability of the domain-constrained optimization module."
            ])
            method_sum = resp.get("methodology_summary", f"{methodology.study_type} using {methodology.validation_protocol}.")
            expected = resp.get("expected_results", "Demonstration of superior benchmark performance and verified reproducibility.")
            future = resp.get("future_work", "Cross-domain generalization and edge deployment optimization.")

            # Generate formatted Markdown & LaTeX documents
            md_doc = self._render_markdown(title, abstract, intro_outline, r_gaps, rqs, hyps, method_sum, expected, future, topic_analysis, literature)
            latex_doc = self._render_latex(title, abstract, intro_outline, r_gaps, rqs, hyps, method_sum, expected, future, topic_analysis)

            return ResearchReportBlueprint(
                title=title,
                abstract=abstract,
                introduction_outline=intro_outline,
                research_gaps=r_gaps,
                research_questions=rqs,
                hypotheses=hyps,
                methodology_summary=method_sum,
                expected_results=expected,
                future_work=future,
                markdown_content=md_doc,
                latex_content=latex_doc
            )
        except Exception as e:
            logger.error(f"Report agent error: {e}. Falling back to template blueprint.")
            title = f"Empirical Investigation into {topic_analysis.topic}"
            abstract = "This blueprint outlines a rigorous experimental study addressing key literature gaps..."
            intro_outline = ["1. Background", "2. Prior Work", "3. Contributions"]
            r_gaps = [gap_analysis.primary_gap_statement]
            rqs = ["RQ1: How to enhance efficiency?", "RQ2: What is the empirical performance impact?"]
            hyps = ["H1: Proposed framework achieves p < 0.05 superiority."]
            method_sum = methodology.validation_protocol
            expected = "Validated benchmark gains."
            future = "Real-world scalability testing."
            md_doc = self._render_markdown(title, abstract, intro_outline, r_gaps, rqs, hyps, method_sum, expected, future, topic_analysis, literature)
            latex_doc = self._render_latex(title, abstract, intro_outline, r_gaps, rqs, hyps, method_sum, expected, future, topic_analysis)

            return ResearchReportBlueprint(
                title=title,
                abstract=abstract,
                introduction_outline=intro_outline,
                research_gaps=r_gaps,
                research_questions=rqs,
                hypotheses=hyps,
                methodology_summary=method_sum,
                expected_results=expected,
                future_work=future,
                markdown_content=md_doc,
                latex_content=latex_doc
            )

    def _render_markdown(
        self, title, abstract, intro, gaps, rqs, hyps, method, expected, future, topic, lit
    ) -> str:
        intro_bullets = "\n".join([f"- {item}" for item in intro])
        gaps_bullets = "\n".join([f"- **Gap {i+1}**: {g}" for i, g in enumerate(gaps)])
        rqs_bullets = "\n".join([f"- **{rq.split(':')[0]}**: {rq.split(':', 1)[1] if ':' in rq else rq}" for rq in rqs])
        hyps_bullets = "\n".join([f"- **{h.split(':')[0]}**: {h.split(':', 1)[1] if ':' in h else h}" for h in hyps])
        lit_papers = "\n".join([f"1. *{p.title}* ({p.year}) - {p.authors[0] if p.authors else 'Et al.'} [Link]({p.url})" for p in lit.papers[:5]])

        return f"""# {title}

**Scientific Domain**: {topic.domain}  
**Generated by**: ResearchPilot AI - Autonomous Research Assistant  

---

## Abstract
{abstract}

---

## 1. Introduction & Background Outline
{intro_bullets}

---

## 2. Key Literature Survey
{lit_papers if lit_papers else "Standard academic benchmarks surveyed."}

---

## 3. Research Gaps & Identified Whitespaces
{gaps_bullets}

---

## 4. Research Questions (RQs)
{rqs_bullets}

---

## 5. Formal Scientific Hypotheses
{hyps_bullets}

---

## 6. Proposed Methodology & Experimental Design
{method}

---

## 7. Anticipated Results & Evaluation Criteria
{expected}

---

## 8. Limitations & Future Research Directions
{future}

---
*Blueprint automatically generated by ResearchPilot AI (Open-Source Multi-Agent Assistant).*
"""

    def _render_latex(
        self, title, abstract, intro, gaps, rqs, hyps, method, expected, future, topic
    ) -> str:
        clean_title = title.replace("&", "\\&").replace("%", "\\%")
        clean_abstract = abstract.replace("&", "\\&").replace("%", "\\%")
        
        return f"""\\documentclass[11pt,a4paper]{{article}}
\\usepackage[utf8]{{inputenc}}
\\usepackage{{amsmath,amssymb}}
\\usepackage{{hyperref}}
\\usepackage{{geometry}}
\\geometry{{margin=1in}}

\\title{{{clean_title}}}
\\author{{ResearchPilot AI Multi-Agent Blueprint \\\\ Scientific Domain: {topic.domain}}}
\\date{{\\today}}

\\begin{{document}}
\\maketitle

\\begin{{abstract}}
{clean_abstract}
\\end{{abstract}}

\\section{{Introduction and Context}}
\\begin{{itemize}}
{"".join([f"    \\item {item}" + chr(10) for item in intro])}
\\end{{itemize}}

\\section{{Research Gaps}}
\\begin{{itemize}}
{"".join([f"    \\item {g}" + chr(10) for g in gaps])}
\\end{{itemize}}

\\section{{Research Questions and Hypotheses}}
\\subsection*{{Research Questions}}
\\begin{{itemize}}
{"".join([f"    \\item {rq}" + chr(10) for rq in rqs])}
\\end{{itemize}}

\\subsection*{{Hypotheses}}
\\begin{{itemize}}
{"".join([f"    \\item {h}" + chr(10) for h in hyps])}
\\end{{itemize}}

\\section{{Methodology and Experimental Design}}
{method.replace("&", "\\&")}

\\section{{Anticipated Results}}
{expected.replace("&", "\\&")}

\\section{{Future Work}}
{future.replace("&", "\\&")}

\\end{{document}}
"""
