"""
Research Director Agent (Workflow Orchestrator & State Machine).

Coordinates the multi-agent scientific team from initial idea through literature discovery,
gap identification, methodology design, and final report blueprint compilation.
"""

from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field
import logging
import time

from backend.agents.topic_agent import TopicUnderstandingAgent, TopicAnalysis
from backend.agents.literature_agent import LiteratureIntelligenceAgent, LiteratureCorpus
from backend.agents.gap_agent import ResearchGapAgent, ResearchGapAnalysis
from backend.agents.methodology_agent import MethodologyAgent, MethodologyBlueprint
from backend.agents.report_agent import ReportGeneratorAgent, ResearchReportBlueprint
from backend.services.llm_service import BaseLLMClient, get_llm_service

logger = logging.getLogger(__name__)


class ResearchWorkflowState(BaseModel):
    """Global multi-agent execution state."""
    workflow_id: str = Field(default_factory=lambda: f"wf_{int(time.time())}")
    topic: str
    domain_preference: Optional[str] = None
    current_step: str = "initialized"
    is_completed: bool = False
    
    # Artifact outputs
    topic_analysis: Optional[TopicAnalysis] = None
    literature: Optional[LiteratureCorpus] = None
    gap_analysis: Optional[ResearchGapAnalysis] = None
    methodology: Optional[MethodologyBlueprint] = None
    report: Optional[ResearchReportBlueprint] = None
    
    # Execution telemetry
    logs: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)


class ResearchDirectorAgent:
    """Project manager orchestrating the specialized research agent team."""

    def __init__(self, llm_service: Optional[BaseLLMClient] = None):
        self.llm = llm_service or get_llm_service()
        self.topic_agent = TopicUnderstandingAgent(llm_service=self.llm)
        self.literature_agent = LiteratureIntelligenceAgent(llm_service=self.llm)
        self.gap_agent = ResearchGapAgent(llm_service=self.llm)
        self.methodology_agent = MethodologyAgent(llm_service=self.llm)
        self.report_agent = ReportGeneratorAgent(llm_service=self.llm)

    def log_step(self, state: ResearchWorkflowState, message: str) -> None:
        """Record timestamped telemetry message."""
        entry = f"[{time.strftime('%H:%M:%S')}] {message}"
        state.logs.append(entry)
        logger.info(entry)

    def run_topic_understanding(self, state: ResearchWorkflowState) -> ResearchWorkflowState:
        """Step 1: Execute Topic Understanding Agent."""
        self.log_step(state, f"Director initiating Topic Understanding for: '{state.topic}'")
        state.current_step = "topic_understanding"
        try:
            state.topic_analysis = self.topic_agent.analyze_topic(
                state.topic, domain_preference=state.domain_preference
            )
            self.log_step(
                state,
                f"Topic understood: Domain='{state.topic_analysis.domain}', Keywords={state.topic_analysis.keywords[:3]}"
            )
        except Exception as e:
            err = f"Topic understanding failed: {str(e)}"
            state.errors.append(err)
            self.log_step(state, f"ERROR: {err}")
        return state

    def run_literature_discovery(self, state: ResearchWorkflowState) -> ResearchWorkflowState:
        """Step 2: Execute Literature Intelligence Agent."""
        if not state.topic_analysis:
            state = self.run_topic_understanding(state)

        self.log_step(state, "Director querying scientific literature (arXiv & Semantic Scholar)")
        state.current_step = "literature_discovery"
        try:
            state.literature = self.literature_agent.discover_literature(state.topic_analysis)
            self.log_step(state, f"Literature indexed: Retrieved {len(state.literature.papers)} papers with structured extraction.")
        except Exception as e:
            err = f"Literature discovery failed: {str(e)}"
            state.errors.append(err)
            self.log_step(state, f"ERROR: {err}")
        return state

    def run_gap_analysis(self, state: ResearchWorkflowState) -> ResearchWorkflowState:
        """Step 3: Execute Research Gap Agent."""
        if not state.literature:
            state = self.run_literature_discovery(state)

        self.log_step(state, "Director initiating Research Gap Identification")
        state.current_step = "gap_analysis"
        try:
            state.gap_analysis = self.gap_agent.identify_gaps(state.topic_analysis, state.literature)
            self.log_step(state, f"Primary gap identified: '{state.gap_analysis.primary_gap_statement[:80]}...'")
        except Exception as e:
            err = f"Gap analysis failed: {str(e)}"
            state.errors.append(err)
            self.log_step(state, f"ERROR: {err}")
        return state

    def run_methodology_design(self, state: ResearchWorkflowState) -> ResearchWorkflowState:
        """Step 4: Execute Methodology Agent."""
        if not state.gap_analysis:
            state = self.run_gap_analysis(state)

        self.log_step(state, "Director drafting Experimental Methodology Protocol")
        state.current_step = "methodology_design"
        try:
            state.methodology = self.methodology_agent.design_methodology(
                state.topic_analysis, state.gap_analysis
            )
            self.log_step(state, f"Methodology established: Study type='{state.methodology.study_type}', Stages={len(state.methodology.pipeline_stages)}")
        except Exception as e:
            err = f"Methodology design failed: {str(e)}"
            state.errors.append(err)
            self.log_step(state, f"ERROR: {err}")
        return state

    def run_report_generation(self, state: ResearchWorkflowState) -> ResearchWorkflowState:
        """Step 5: Execute Report Generator Agent."""
        if not state.methodology:
            state = self.run_methodology_design(state)

        self.log_step(state, "Director compiling formal Research Blueprint Report")
        state.current_step = "report_generation"
        try:
            state.report = self.report_agent.generate_report(
                state.topic_analysis, state.literature, state.gap_analysis, state.methodology
            )
            state.is_completed = True
            state.current_step = "completed"
            self.log_step(state, f"Research Blueprint generated successfully: '{state.report.title}'")
        except Exception as e:
            err = f"Report generation failed: {str(e)}"
            state.errors.append(err)
            self.log_step(state, f"ERROR: {err}")
        return state

    def execute_full_workflow(
        self,
        topic: str,
        domain_preference: Optional[str] = None
    ) -> ResearchWorkflowState:
        """Execute the complete autonomous research workflow from idea to final blueprint."""
        state = ResearchWorkflowState(topic=topic, domain_preference=domain_preference)
        self.log_step(state, f"=== Research Director Initializing Workflow: {state.workflow_id} ===")
        
        state = self.run_topic_understanding(state)
        state = self.run_literature_discovery(state)
        state = self.run_gap_analysis(state)
        state = self.run_methodology_design(state)
        state = self.run_report_generation(state)
        
        self.log_step(state, "=== Research Workflow Finished Successfully ===")
        return state
