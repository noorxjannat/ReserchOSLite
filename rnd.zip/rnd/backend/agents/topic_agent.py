"""
Topic Understanding Agent.

Deconstructs scientific research ideas into taxonomy, domains, keywords, and foundational challenges.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
import logging

from backend.services.llm_service import BaseLLMClient, get_llm_service
from domains.base import PluginRegistry

logger = logging.getLogger(__name__)


class TopicAnalysis(BaseModel):
    """Structured scientific topic deconstruction."""
    topic: str
    domain: str = Field(description="Primary scientific domain or field")
    domain_key: str = Field(default="cse", description="Plugin key matching domain")
    keywords: List[str] = Field(default_factory=list, description="Core scientific keywords")
    subtopics: List[str] = Field(default_factory=list, description="Active subfields and branches")
    research_challenges: List[str] = Field(default_factory=list, description="Key scientific bottlenecks")


class TopicUnderstandingAgent:
    """Agent responsible for topic understanding and domain categorization."""

    def __init__(self, llm_service: Optional[BaseLLMClient] = None):
        self.llm = llm_service or get_llm_service()

    def analyze_topic(self, topic: str, domain_preference: Optional[str] = None) -> TopicAnalysis:
        """Analyze research idea and extract structured taxonomy."""
        prompt = f"""
You are the Topic Understanding Agent in ResearchPilot AI.
Deconstruct the following research idea or scientific problem:

RESEARCH TOPIC:
"{topic}"

DOMAIN PREFERENCE (if any):
"{domain_preference or 'Auto-detect'}"

Return a JSON object with this exact structure:
{{
  "domain": "Scientific Domain (e.g., Computer Science / Agriculture AI / Power Systems / Genetics)",
  "domain_key": "cse" (one of: 'cse', 'eee', 'genetics', or 'cse' as default),
  "keywords": ["Keyword1", "Keyword2", "Keyword3", "Keyword4", "Keyword5"],
  "subtopics": [
    "Subtopic branch 1",
    "Subtopic branch 2",
    "Subtopic branch 3"
  ],
  "research_challenges": [
    "Challenge 1: Description of fundamental difficulty",
    "Challenge 2: Description of validation bottleneck",
    "Challenge 3: Description of scalability barrier"
  ]
}}
"""
        # Inject domain prompt enhancement if domain is known
        plugin = PluginRegistry.get(domain_preference) if domain_preference else None
        system_prompt = (
            "You are an expert scientific taxonomist and domain researcher."
            + (f"\n{plugin.get_system_prompt_enhancements()}" if plugin else "")
        )

        try:
            response = self.llm.generate_json(prompt, system_prompt=system_prompt)
            # Infer domain key if needed
            domain_key = response.get("domain_key", "cse").lower()
            if domain_preference and domain_preference in ["cse", "eee", "genetics"]:
                domain_key = domain_preference

            return TopicAnalysis(
                topic=topic,
                domain=response.get("domain", "Computer Science & Engineering"),
                domain_key=domain_key if domain_key in ["cse", "eee", "genetics"] else "cse",
                keywords=response.get("keywords", ["Machine Learning", "Optimization", "Empirical Evaluation"]),
                subtopics=response.get("subtopics", ["Feature Engineering", "Model Design", "Validation Protocols"]),
                research_challenges=response.get("research_challenges", [
                    "High sensitivity to noisy data",
                    "Limited field validation under production constraints",
                    "Ablation gaps in component contribution"
                ])
            )
        except Exception as e:
            logger.error(f"Topic agent analysis failed: {e}. Returning safe fallback.")
            return TopicAnalysis(
                topic=topic,
                domain="Computer Science & Engineering",
                domain_key=domain_preference or "cse",
                keywords=["Machine Learning", "Deep Neural Networks", "Empirical Benchmarking"],
                subtopics=["Model Architecture", "Data Pipeline", "Generalization Analysis"],
                research_challenges=["Dataset distribution shift", "Computational complexity in edge deployment"]
            )
