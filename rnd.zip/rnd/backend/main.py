"""
FastAPI Backend Application for ResearchPilot AI.

Exposes REST APIs for autonomous multi-agent research workflow, literature queries,
RAG scientific retrieval, domain plugins, data analysis, and blueprint generation.
"""

from typing import Optional, List, Dict, Any
from pathlib import Path
from fastapi import FastAPI, HTTPException, Query, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import io
from pydantic import BaseModel, Field

from config import settings
from domains.base import PluginRegistry
import domains.cse
import domains.eee
import domains.genetics

from backend.agents.research_director import ResearchDirectorAgent, ResearchWorkflowState
from backend.agents.topic_agent import TopicUnderstandingAgent, TopicAnalysis
from backend.agents.literature_agent import LiteratureIntelligenceAgent, LiteratureCorpus
from backend.agents.gap_agent import ResearchGapAgent, ResearchGapAnalysis
from backend.agents.methodology_agent import MethodologyAgent, MethodologyBlueprint
from backend.agents.report_agent import ReportGeneratorAgent, ResearchReportBlueprint
from backend.agents.data_agent import DataAnalysisAgent, EmpiricalAnalysisReport
from backend.services.paper_search import PaperSearchService, ScientificPaper
from backend.services.document_processor import DocumentProcessor
from backend.rag.vector_store import ScientificVectorStore
from backend.rag.retriever import ScientificRAGRetriever
from backend.services.llm_service import get_llm_service

app = FastAPI(
    title="ResearchPilot AI API",
    description="Autonomous Multi-Agent Scientific Research Workflow Engine",
    version=settings.APP_VERSION,
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS middleware for local frontend connectivity
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize shared RAG vector store and retriever
global_vector_store = ScientificVectorStore()
global_retriever = ScientificRAGRetriever(vector_store=global_vector_store)
global_doc_processor = DocumentProcessor()


# Schemas
class ResearchRequest(BaseModel):
    topic: str = Field(..., json_schema_extra={"example": "Deep learning for edge plant disease diagnosis"})
    domain_preference: Optional[str] = Field(default=None, json_schema_extra={"example": "cse"})
    provider: Optional[str] = Field(default=None, json_schema_extra={"example": "mock"})


class RAGQueryRequest(BaseModel):
    question: str = Field(..., json_schema_extra={"example": "According to previous studies, what methods are commonly used?"})
    top_k: int = Field(default=4, ge=1, le=10)


class DomainToolRequest(BaseModel):
    parameters: Dict[str, Any] = Field(default_factory=dict)


@app.get("/api/health")
def get_health() -> Dict[str, Any]:
    """Return system status, active LLM provider, and registered domains."""
    return {
        "status": "healthy",
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "active_llm_provider": settings.LLM_PROVIDER,
        "registered_domains": [d["key"] for d in PluginRegistry.list_domains()],
        "rag_indexed_chunks": len(global_vector_store.chunks)
    }


@app.get("/api/domains")
def get_registered_domains() -> List[Dict[str, Any]]:
    """List all registered scientific domain plugins and their metrics."""
    domains_data = []
    for d in PluginRegistry.list_domains():
        plugin = PluginRegistry.get(d["key"])
        domains_data.append({
            "key": d["key"],
            "name": d["name"],
            "description": d["description"],
            "metrics": [m.model_dump() for m in plugin.get_domain_metrics()] if plugin else [],
            "tools": [t.model_dump() for t in plugin.get_domain_tools()] if plugin else []
        })
    return domains_data


@app.post("/api/research/workflow", response_model=ResearchWorkflowState)
def run_full_workflow(req: ResearchRequest) -> ResearchWorkflowState:
    """Execute the end-to-end multi-agent research workflow."""
    llm = get_llm_service(provider=req.provider) if req.provider else None
    director = ResearchDirectorAgent(llm_service=llm)
    state = director.execute_full_workflow(
        topic=req.topic,
        domain_preference=req.domain_preference
    )
    return state


@app.post("/api/research/topic", response_model=TopicAnalysis)
def analyze_topic(req: ResearchRequest) -> TopicAnalysis:
    """Execute Topic Understanding Agent."""
    llm = get_llm_service(provider=req.provider) if req.provider else None
    agent = TopicUnderstandingAgent(llm_service=llm)
    return agent.analyze_topic(req.topic, domain_preference=req.domain_preference)


@app.post("/api/research/literature", response_model=LiteratureCorpus)
def search_literature(topic_analysis: TopicAnalysis, max_papers: int = Query(6, ge=1, le=20)) -> LiteratureCorpus:
    """Execute Literature Intelligence Agent."""
    agent = LiteratureIntelligenceAgent()
    return agent.discover_literature(topic_analysis, max_papers=max_papers)


@app.post("/api/research/gaps", response_model=ResearchGapAnalysis)
def identify_gaps(payload: Dict[str, Any]) -> ResearchGapAnalysis:
    """Execute Research Gap Agent."""
    try:
        topic_analysis = TopicAnalysis(**payload["topic_analysis"])
        literature = LiteratureCorpus(**payload["literature"])
        agent = ResearchGapAgent()
        return agent.identify_gaps(topic_analysis, literature)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid payload for gap analysis: {str(e)}")


@app.post("/api/research/methodology", response_model=MethodologyBlueprint)
def design_methodology(payload: Dict[str, Any]) -> MethodologyBlueprint:
    """Execute Methodology Agent."""
    try:
        topic_analysis = TopicAnalysis(**payload["topic_analysis"])
        gap_analysis = ResearchGapAnalysis(**payload["gap_analysis"])
        agent = MethodologyAgent()
        return agent.design_methodology(topic_analysis, gap_analysis)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid payload for methodology: {str(e)}")


@app.post("/api/research/report", response_model=ResearchReportBlueprint)
def generate_report(payload: Dict[str, Any]) -> ResearchReportBlueprint:
    """Execute Report Generator Agent."""
    try:
        topic_analysis = TopicAnalysis(**payload["topic_analysis"])
        literature = LiteratureCorpus(**payload["literature"])
        gap_analysis = ResearchGapAnalysis(**payload["gap_analysis"])
        methodology = MethodologyBlueprint(**payload["methodology"])
        agent = ReportGeneratorAgent()
        return agent.generate_report(topic_analysis, literature, gap_analysis, methodology)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid payload for report: {str(e)}")


@app.get("/api/papers/search")
def search_papers(query: str = Query(..., min_length=2), limit: int = Query(5, ge=1, le=20)) -> List[ScientificPaper]:
    """Direct search endpoint for scientific literature."""
    service = PaperSearchService()
    return service.search(query, max_results=limit)


# RAG Retrieval Endpoints
@app.post("/api/rag/ingest")
async def ingest_document(file: UploadFile = File(...)) -> Dict[str, Any]:
    """Ingest a PDF or text scientific paper into the RAG vector index."""
    temp_dir = settings.PAPERS_DIR
    temp_dir.mkdir(parents=True, exist_ok=True)
    temp_file = temp_dir / file.filename

    content = await file.read()
    temp_file.write_bytes(content)

    chunks = global_doc_processor.process_file(temp_file, doc_id=temp_file.stem)
    count = global_vector_store.add_chunks(chunks)

    return {
        "status": "success",
        "filename": file.filename,
        "chunks_indexed": count,
        "total_store_chunks": len(global_vector_store.chunks)
    }


@app.post("/api/rag/query")
def query_rag(req: RAGQueryRequest) -> Dict[str, Any]:
    """Query scientific literature using RAG grounded retrieval."""
    return global_retriever.query(req.question, top_k=req.top_k)


# Data Analysis Endpoints
@app.get("/api/data/datasets")
def list_sample_datasets() -> List[Dict[str, Any]]:
    """List available sample scientific demonstration datasets."""
    datasets = [
        {
            "id": "cse_edge_faults",
            "name": "CSE Edge IoT Fault Classification",
            "domain": "Computer Science & AI",
            "filename": "cse_edge_faults.csv",
            "task_type": "Classification",
            "target_column": "operational_status",
            "description": "Multivariate sensor data measuring vibration, temperature, CPU, and packet loss."
        },
        {
            "id": "eee_grid_stability",
            "name": "EEE Microgrid Voltage & Stability Simulation",
            "domain": "Electrical Engineering",
            "filename": "eee_grid_stability.csv",
            "task_type": "Regression",
            "target_column": "grid_stability_score",
            "description": "Simulation metrics assessing THD %, voltage regulation, active/reactive power."
        },
        {
            "id": "genetics_rna_diff_expr",
            "name": "Genetics RNA-Seq Differential Expression",
            "domain": "Genetic Engineering",
            "filename": "genetics_rna_diff_expr.csv",
            "task_type": "Regression",
            "target_column": "log2_fold_change",
            "description": "Differential expression dataset with log2FC, p-values, and TPM expression levels."
        }
    ]
    return datasets


@app.post("/api/data/analyze", response_model=EmpiricalAnalysisReport)
async def analyze_dataset_file(
    file: Optional[UploadFile] = File(None),
    dataset_id: Optional[str] = Form(None),
    target_column: Optional[str] = Form(None),
    task_type: Optional[str] = Form(None)
) -> EmpiricalAnalysisReport:
    """Analyze uploaded CSV or sample dataset with statistics, correlation, and ML baselines."""
    if file:
        content = await file.read()
        df = pd.read_csv(io.BytesIO(content))
        name = file.filename
    elif dataset_id:
        file_path = settings.DATASETS_DIR / f"{dataset_id}.csv"
        if not file_path.exists():
            raise HTTPException(status_code=404, detail=f"Dataset '{dataset_id}' not found.")
        df = pd.read_csv(file_path)
        name = file_path.name
    else:
        raise HTTPException(status_code=400, detail="Must provide either an uploaded file or dataset_id.")

    agent = DataAnalysisAgent()
    return agent.analyze_dataset(
        df=df,
        dataset_name=name,
        target_column=target_column,
        task_type=task_type
    )


@app.post("/api/domains/{domain_key}/tools/{tool_id}")
def execute_domain_tool(domain_key: str, tool_id: str, req: DomainToolRequest) -> Dict[str, Any]:
    """Execute a specialized calculation tool registered under a domain plugin."""
    plugin = PluginRegistry.get(domain_key)
    if not plugin:
        raise HTTPException(status_code=404, detail=f"Domain plugin '{domain_key}' not found.")
    return plugin.execute_domain_tool(tool_id, **req.parameters)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host=settings.BACKEND_HOST, port=settings.BACKEND_PORT, reload=settings.DEBUG)
