"""
RAG (Retrieval-Augmented Generation) package for scientific papers.
"""

from backend.rag.embeddings import get_embeddings_service, BaseEmbeddings
from backend.rag.vector_store import ScientificVectorStore
from backend.rag.retriever import ScientificRAGRetriever

__all__ = ["get_embeddings_service", "BaseEmbeddings", "ScientificVectorStore", "ScientificRAGRetriever"]
