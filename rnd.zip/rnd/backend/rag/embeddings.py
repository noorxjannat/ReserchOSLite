"""
Scientific Embeddings Module.

Provides semantic embedding representation for research documents.
Includes TF-IDF and hashing vectorizer as resilient built-in, with optional sentence-transformers.
"""

from abc import ABC, abstractmethod
from typing import List
import numpy as np
import logging
from sklearn.feature_extraction.text import TfidfVectorizer

logger = logging.getLogger(__name__)


class BaseEmbeddings(ABC):
    """Abstract vector embedding generator."""

    @abstractmethod
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        pass

    @abstractmethod
    def embed_query(self, text: str) -> List[float]:
        pass


class ScientificTfidfEmbeddings(BaseEmbeddings):
    """Fast, reproducible TF-IDF vectorizer for scientific documents."""

    def __init__(self, max_features: int = 512):
        self.max_features = max_features
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            stop_words="english",
            ngram_range=(1, 2)
        )
        self._is_fitted = False
        self._fallback_dim = max_features

    def _hash_vector(self, text: str) -> List[float]:
        """Deterministic hashing fallback when vocabulary is uninitialized."""
        vec = np.zeros(self._fallback_dim, dtype=np.float32)
        for word in text.lower().split():
            idx = abs(hash(word)) % self._fallback_dim
            vec[idx] += 1.0
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm
        return vec.tolist()

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []
        try:
            if not self._is_fitted:
                matrix = self.vectorizer.fit_transform(texts).toarray()
                self._is_fitted = True
            else:
                matrix = self.vectorizer.transform(texts).toarray()
            return matrix.tolist()
        except Exception as e:
            logger.warning(f"TF-IDF fitting fallback: {e}")
            return [self._hash_vector(t) for t in texts]

    def embed_query(self, text: str) -> List[float]:
        if not self._is_fitted:
            return self._hash_vector(text)
        try:
            res = self.vectorizer.transform([text]).toarray()[0]
            norm = np.linalg.norm(res)
            if norm > 0:
                res = res / norm
            return res.tolist()
        except Exception:
            dim = len(self.vectorizer.get_feature_names_out()) if self._is_fitted else self._fallback_dim
            return [0.0] * dim


def get_embeddings_service() -> BaseEmbeddings:
    """Return the active embeddings service."""
    return ScientificTfidfEmbeddings()
