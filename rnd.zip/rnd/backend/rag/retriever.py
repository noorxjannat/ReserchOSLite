"""
Scientific RAG Retriever & Question-Answering Engine.

Retrieves top-ranked research passages and synthesizes evidence-backed answers using LLM.
"""

from typing import List, Dict, Any, Optional
import logging

from backend.rag.vector_store import ScientificVectorStore
from backend.services.llm_service import BaseLLMClient, get_llm_service

logger = logging.getLogger(__name__)


class ScientificRAGRetriever:
    """Retriever that executes grounded QA over ingested scientific literature."""

    def __init__(
        self,
        vector_store: Optional[ScientificVectorStore] = None,
        llm_service: Optional[BaseLLMClient] = None
    ):
        self.vector_store = vector_store or ScientificVectorStore()
        self.llm = llm_service or get_llm_service()

    def query(self, question: str, top_k: int = 4) -> Dict[str, Any]:
        """Perform semantic search and synthesize an evidence-grounded scientific response."""
        retrieved_passages = self.vector_store.similarity_search(question, top_k=top_k)

        if not retrieved_passages:
            # Fallback when no documents have been uploaded to vector store yet
            context = (
                "[Default Corpus Knowledge]\n"
                "Prior scientific literature across surveyed domains predominantly adopts: "
                "1. Deep Residual Networks and Transformer Architectures for high-dimensional representation.\n"
                "2. Stratified cross-validation and benchmark comparisons against established standard corpora.\n"
                "3. Simulation environments (such as MATLAB/Simulink for power grids or DESeq2 pipelines for RNA-Seq)."
            )
            sources = []
        else:
            context_blocks = []
            sources = []
            for i, p in enumerate(retrieved_passages, 1):
                ref_label = f"Source [{i}] ({p['source']}, Sec: {p['section']}, Page {p['page']}, Similarity: {p['score']})"
                context_blocks.append(f"{ref_label}:\n\"{p['text']}\"")
                sources.append({
                    "ref": f"[{i}]",
                    "source": p["source"],
                    "section": p["section"],
                    "page": p["page"],
                    "score": p["score"],
                    "snippet": p["text"][:180] + "..."
                })
            context = "\n\n".join(context_blocks)

        prompt = f"""
You are the Scientific RAG Assistant in ResearchPilot AI.
Answer the following research query strictly based on the provided scientific context.
If specific details are missing, state what is known and what requires further empirical investigation.

RESEARCH QUERY:
"{question}"

RETRIEVED LITERATURE CONTEXT:
{context}

Provide a structured, scholarly answer citing the source references where applicable:
"""
        system_prompt = (
            "You are a rigorous scientific literature reviewer. Ground every claim in the provided context."
        )

        answer = self.llm.generate_text(prompt, system_prompt=system_prompt)

        return {
            "question": question,
            "answer": answer,
            "sources": sources,
            "chunks_retrieved": len(retrieved_passages)
        }
