"""
Scientific Vector Store Manager.

Stores document vectors, performs cosine similarity searches, and manages persistence.
"""

from typing import List, Dict, Any, Optional
import json
from pathlib import Path
import numpy as np
import logging

from config import settings
from backend.services.document_processor import DocumentChunk
from backend.rag.embeddings import BaseEmbeddings, get_embeddings_service

logger = logging.getLogger(__name__)


class ScientificVectorStore:
    """In-memory and persistent vector index for scientific research chunks."""

    def __init__(
        self,
        persist_dir: Optional[Path] = None,
        embeddings: Optional[BaseEmbeddings] = None
    ):
        self.persist_dir = persist_dir or settings.CHROMA_PERSIST_DIR
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self.embeddings = embeddings or get_embeddings_service()

        self.chunks: List[DocumentChunk] = []
        self.vectors: np.ndarray = np.empty((0, 512), dtype=np.float32)

    def add_chunks(self, new_chunks: List[DocumentChunk]) -> int:
        """Embed and append new chunks to the vector index."""
        if not new_chunks:
            return 0

        texts = [c.text for c in new_chunks]
        new_vecs = np.array(self.embeddings.embed_documents(texts), dtype=np.float32)

        if self.vectors.shape[0] == 0:
            self.vectors = new_vecs
        else:
            # Handle potential dimension mismatch if vectorizer re-fitted
            if self.vectors.shape[1] != new_vecs.shape[1]:
                all_texts = [c.text for c in self.chunks] + texts
                self.vectors = np.array(self.embeddings.embed_documents(all_texts), dtype=np.float32)
            else:
                self.vectors = np.vstack([self.vectors, new_vecs])

        self.chunks.extend(new_chunks)
        logger.info(f"Added {len(new_chunks)} chunks to vector store. Total index size: {len(self.chunks)}.")
        return len(new_chunks)

    def similarity_search(self, query: str, top_k: int = 4) -> List[Dict[str, Any]]:
        """Retrieve most semantically similar chunks for a query using cosine similarity."""
        if len(self.chunks) == 0 or self.vectors.shape[0] == 0:
            return []

        query_vec = np.array(self.embeddings.embed_query(query), dtype=np.float32)

        # Defensive dimension alignment
        target_dim = self.vectors.shape[1]
        if query_vec.shape[0] < target_dim:
            query_vec = np.pad(query_vec, (0, target_dim - query_vec.shape[0]))
        elif query_vec.shape[0] > target_dim:
            query_vec = query_vec[:target_dim]

        # Normalize query vector
        q_norm = np.linalg.norm(query_vec)
        if q_norm > 0:
            query_vec /= q_norm

        # Normalize stored vectors
        v_norms = np.linalg.norm(self.vectors, axis=1, keepdims=True)
        v_norms[v_norms == 0] = 1.0
        normalized_vectors = self.vectors / v_norms

        # Cosine similarities
        scores = np.dot(normalized_vectors, query_vec)

        # Top K indices
        top_indices = np.argsort(scores)[::-1][:top_k]

        results = []
        for idx in top_indices:
            score = float(scores[idx])
            chunk = self.chunks[idx]
            results.append({
                "score": round(score, 4),
                "chunk": chunk,
                "text": chunk.text,
                "section": chunk.section,
                "page": chunk.page_number,
                "source": chunk.metadata.get("source", "Document")
            })

        return results

    def save_index(self, filename: str = "index.json") -> Path:
        """Persist chunk metadata to JSON."""
        save_path = self.persist_dir / filename
        data = [c.model_dump() for c in self.chunks]
        save_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return save_path

    def load_index(self, filename: str = "index.json") -> int:
        """Load persisted index from disk."""
        save_path = self.persist_dir / filename
        if not save_path.exists():
            return 0
        try:
            raw_data = json.loads(save_path.read_text(encoding="utf-8"))
            chunks = [DocumentChunk(**item) for item in raw_data]
            self.chunks = []
            self.vectors = np.empty((0, 512), dtype=np.float32)
            self.add_chunks(chunks)
            return len(chunks)
        except Exception as e:
            logger.error(f"Error loading index: {e}")
            return 0
