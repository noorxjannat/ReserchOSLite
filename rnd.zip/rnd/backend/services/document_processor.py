"""
Scientific Document Processing Service.

Parses scientific PDF documents and text files, performs citation-aware chunking,
and extracts structural sections (Abstract, Methodology, Results).
"""

from typing import List, Dict, Any, Optional
from pathlib import Path
import re
import logging
from pydantic import BaseModel, Field

try:
    import pypdf
    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False

logger = logging.getLogger(__name__)


class DocumentChunk(BaseModel):
    """Text chunk extracted from scientific paper or document."""
    chunk_id: str
    doc_id: str
    text: str
    section: str = Field(default="Body")
    page_number: int = Field(default=1)
    token_count: int = Field(default=0)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DocumentProcessor:
    """Scientific document parser and semantic chunker."""

    def __init__(self, chunk_size: int = 800, chunk_overlap: int = 120):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def extract_text_from_pdf(self, file_path: Path) -> List[Dict[str, Any]]:
        """Extract text page-by-page from a PDF file."""
        if not HAS_PYPDF:
            logger.error("pypdf is not installed.")
            return [{"page": 1, "text": "pypdf package missing."}]

        pages_data = []
        try:
            reader = pypdf.PdfReader(str(file_path))
            for idx, page in enumerate(reader.pages):
                text = page.extract_text() or ""
                # Basic cleaning of line wraps and null characters
                cleaned = re.sub(r"\x00", "", text)
                cleaned = re.sub(r"(?<=\w)-\n(?=\w)", "", cleaned)  # de-hyphenate line breaks
                pages_data.append({
                    "page": idx + 1,
                    "text": cleaned.strip()
                })
        except Exception as e:
            logger.error(f"Error reading PDF file {file_path}: {e}")
            pages_data.append({"page": 1, "text": f"Error extracting PDF: {str(e)}"})

        return pages_data

    def chunk_document(
        self,
        text: str,
        doc_id: str = "doc_1",
        page_number: int = 1,
        source_title: str = ""
    ) -> List[DocumentChunk]:
        """Split text into overlapping semantic chunks preserving sentence boundaries."""
        if not text.strip():
            return []

        # Split into sentence candidates
        sentences = re.split(r"(?<=[.!?])\s+", text)
        chunks: List[DocumentChunk] = []

        current_words: List[str] = []
        current_len = 0
        chunk_idx = 1
        current_section = self._detect_section(text[:300])

        for sent in sentences:
            words = sent.split()
            sent_len = len(words)

            if current_len + sent_len > self.chunk_size and current_words:
                chunk_text = " ".join(current_words)
                chunks.append(DocumentChunk(
                    chunk_id=f"{doc_id}_c{chunk_idx}",
                    doc_id=doc_id,
                    text=chunk_text,
                    section=current_section,
                    page_number=page_number,
                    token_count=len(current_words),
                    metadata={"source": source_title, "page": page_number}
                ))
                chunk_idx += 1

                # Keep overlap from tail
                overlap_words = current_words[-self.chunk_overlap:] if len(current_words) > self.chunk_overlap else []
                current_words = overlap_words + words
                current_len = len(current_words)
            else:
                current_words.extend(words)
                current_len += sent_len

            # Check if sentence is a section header
            detected = self._detect_section(sent)
            if detected != "Body":
                current_section = detected

        if current_words:
            chunk_text = " ".join(current_words)
            chunks.append(DocumentChunk(
                chunk_id=f"{doc_id}_c{chunk_idx}",
                doc_id=doc_id,
                text=chunk_text,
                section=current_section,
                page_number=page_number,
                token_count=len(current_words),
                metadata={"source": source_title, "page": page_number}
            ))

        return chunks

    def process_file(self, file_path: Path, doc_id: Optional[str] = None) -> List[DocumentChunk]:
        """Process any PDF or text file and return semantic chunks."""
        file_path = Path(file_path)
        doc_identifier = doc_id or file_path.stem

        all_chunks: List[DocumentChunk] = []
        if file_path.suffix.lower() == ".pdf":
            pages = self.extract_text_from_pdf(file_path)
            for p in pages:
                chunks = self.chunk_document(
                    p["text"],
                    doc_id=doc_identifier,
                    page_number=p["page"],
                    source_title=file_path.name
                )
                all_chunks.extend(chunks)
        else:
            # Plain text or markdown
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                all_chunks = self.chunk_document(
                    content,
                    doc_id=doc_identifier,
                    page_number=1,
                    source_title=file_path.name
                )
            except Exception as e:
                logger.error(f"Error reading file {file_path}: {e}")

        return all_chunks

    def _detect_section(self, text: str) -> str:
        """Heuristically identify scientific section headers."""
        lower = text.lower()
        if "abstract" in lower:
            return "Abstract"
        elif "introduction" in lower:
            return "Introduction"
        elif "related work" in lower or "literature" in lower:
            return "Literature Review"
        elif "method" in lower or "architecture" in lower or "system model" in lower:
            return "Methodology"
        elif "experiment" in lower or "result" in lower or "evaluation" in lower:
            return "Results & Discussion"
        elif "conclusion" in lower or "future work" in lower:
            return "Conclusion"
        return "Body"
