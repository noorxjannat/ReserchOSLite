"""
Centralized Configuration & Environment Validation for ResearchPilot AI.
"""

import os
from pathlib import Path
from typing import Literal, Optional

# Load local .env if present
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_DIR = Path(__file__).resolve().parent

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict
    HAS_PYDANTIC_SETTINGS = True
except ImportError:
    HAS_PYDANTIC_SETTINGS = False
    from pydantic import BaseModel


if HAS_PYDANTIC_SETTINGS:
    class Settings(BaseSettings):
        model_config = SettingsConfigDict(
            env_file=str(BASE_DIR / ".env"),
            env_file_encoding="utf-8",
            extra="ignore"
        )

        APP_NAME: str = "ResearchPilot AI"
        APP_VERSION: str = "1.0.0"
        ENVIRONMENT: Literal["development", "production", "testing"] = "development"
        DEBUG: bool = True

        BACKEND_HOST: str = "127.0.0.1"
        BACKEND_PORT: int = 8000
        FRONTEND_PORT: int = 8501

        LLM_PROVIDER: Literal["gemini", "openai", "mock"] = os.getenv("LLM_PROVIDER", "mock")
        GEMINI_API_KEY: Optional[str] = os.getenv("GEMINI_API_KEY")
        OPENAI_API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY")

        GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.2"))
        LLM_MAX_TOKENS: int = int(os.getenv("LLM_MAX_TOKENS", "4096"))

        SEMANTIC_SCHOLAR_API_KEY: Optional[str] = os.getenv("SEMANTIC_SCHOLAR_API_KEY")
        ARXIV_MAX_RESULTS: int = int(os.getenv("ARXIV_MAX_RESULTS", "10"))
        SEMANTIC_SCHOLAR_MAX_RESULTS: int = int(os.getenv("SEMANTIC_SCHOLAR_MAX_RESULTS", "10"))

        DATA_DIR: Path = BASE_DIR / "data"
        PAPERS_DIR: Path = BASE_DIR / "data" / "papers"
        DATASETS_DIR: Path = BASE_DIR / "data" / "datasets"
        CHROMA_PERSIST_DIR: Path = BASE_DIR / "data" / "chroma_db"

        CHUNK_SIZE: int = 1000
        CHUNK_OVERLAP: int = 150
        EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"

    settings = Settings()
else:
    class FallbackSettings:
        APP_NAME: str = "ResearchPilot AI"
        APP_VERSION: str = "1.0.0"
        ENVIRONMENT: str = "development"
        DEBUG: bool = True

        BACKEND_HOST: str = os.getenv("BACKEND_HOST", "127.0.0.1")
        BACKEND_PORT: int = int(os.getenv("BACKEND_PORT", "8000"))
        FRONTEND_PORT: int = int(os.getenv("FRONTEND_PORT", "8501"))

        LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "mock")
        GEMINI_API_KEY: Optional[str] = os.getenv("GEMINI_API_KEY")
        OPENAI_API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY")

        GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.2"))
        LLM_MAX_TOKENS: int = int(os.getenv("LLM_MAX_TOKENS", "4096"))

        SEMANTIC_SCHOLAR_API_KEY: Optional[str] = os.getenv("SEMANTIC_SCHOLAR_API_KEY")
        ARXIV_MAX_RESULTS: int = int(os.getenv("ARXIV_MAX_RESULTS", "10"))
        SEMANTIC_SCHOLAR_MAX_RESULTS: int = int(os.getenv("SEMANTIC_SCHOLAR_MAX_RESULTS", "10"))

        DATA_DIR: Path = BASE_DIR / "data"
        PAPERS_DIR: Path = BASE_DIR / "data" / "papers"
        DATASETS_DIR: Path = BASE_DIR / "data" / "datasets"
        CHROMA_PERSIST_DIR: Path = BASE_DIR / "data" / "chroma_db"

        CHUNK_SIZE: int = 1000
        CHUNK_OVERLAP: int = 150
        EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"

    settings = FallbackSettings()

settings.DATA_DIR.mkdir(parents=True, exist_ok=True)
settings.PAPERS_DIR.mkdir(parents=True, exist_ok=True)
settings.DATASETS_DIR.mkdir(parents=True, exist_ok=True)
settings.CHROMA_PERSIST_DIR.mkdir(parents=True, exist_ok=True)
