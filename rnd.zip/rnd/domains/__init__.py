"""
Domain Plugin Architecture for ResearchPilot AI.

Enables seamless expansion across scientific disciplines (CSE, EEE, Genetics, Agriculture, Medicine, Chemistry).
"""

from domains.base import DomainPlugin, PluginRegistry, DomainMetric, DomainTool

__all__ = ["DomainPlugin", "PluginRegistry", "DomainMetric", "DomainTool"]
