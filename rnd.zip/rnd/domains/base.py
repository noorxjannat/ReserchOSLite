"""
Base Domain Plugin Interface & Dynamic Plugin Registry.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field


class DomainMetric(BaseModel):
    """Scientific evaluation metric definition."""
    name: str = Field(..., description="Metric display name")
    symbol: str = Field(..., description="Short symbol or acronym")
    description: str = Field(..., description="Scientific meaning and use-case")
    unit: str = Field(default="", description="Unit of measurement, if applicable")
    higher_is_better: bool = Field(default=True, description="Direction of optimization")
    benchmark_baseline: Optional[str] = Field(default=None, description="Typical acceptable baseline")


class DomainTool(BaseModel):
    """Domain-specific computation or validation tool."""
    tool_id: str
    name: str
    description: str
    parameters: Dict[str, Any] = Field(default_factory=dict)


class DomainPlugin(ABC):
    """Abstract interface for all scientific domain plugins."""

    @property
    @abstractmethod
    def domain_key(self) -> str:
        """Unique lowercase identifier for the domain (e.g. 'cse', 'eee', 'genetics')."""
        pass

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Human-readable scientific domain name."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Brief scientific description and subfields."""
        pass

    @abstractmethod
    def get_system_prompt_enhancements(self) -> str:
        """Domain-specific scientific guidelines and conventions injected into agent prompts."""
        pass

    @abstractmethod
    def get_domain_metrics(self) -> List[DomainMetric]:
        """List of standard domain metrics used for methodology and evaluation."""
        pass

    @abstractmethod
    def get_domain_tools(self) -> List[DomainTool]:
        """List of domain tools."""
        pass

    def validate_methodology(self, methodology: Dict[str, Any]) -> Dict[str, Any]:
        """Default validation hook for methodology specifications."""
        metrics = [m.name for m in self.get_domain_metrics()]
        return {
            "is_valid": True,
            "recommended_metrics": metrics,
            "domain": self.display_name,
            "warnings": []
        }

    def execute_domain_tool(self, tool_id: str, **kwargs) -> Dict[str, Any]:
        """Execute a domain-specific calculation or check."""
        return {
            "status": "not_implemented",
            "tool_id": tool_id,
            "message": f"Tool '{tool_id}' not implemented in {self.display_name}."
        }


class PluginRegistry:
    """Singleton registry managing active scientific domain plugins."""

    _instance: Optional["PluginRegistry"] = None
    _plugins: Dict[str, DomainPlugin] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(PluginRegistry, cls).__new__(cls)
            cls._plugins = {}
        return cls._instance

    @classmethod
    def register(cls, plugin: DomainPlugin) -> None:
        """Register a new scientific domain plugin."""
        cls._plugins[plugin.domain_key.lower()] = plugin

    @classmethod
    def get(cls, domain_key: str) -> Optional[DomainPlugin]:
        """Retrieve a registered plugin by key."""
        return cls._plugins.get(domain_key.lower())

    @classmethod
    def list_domains(cls) -> List[Dict[str, str]]:
        """Return metadata for all registered scientific plugins."""
        return [
            {
                "key": key,
                "name": plugin.display_name,
                "description": plugin.description
            }
            for key, plugin in cls._plugins.items()
        ]

    @classmethod
    def get_all(cls) -> Dict[str, DomainPlugin]:
        return cls._plugins.copy()
