"""
Computer Science & Artificial Intelligence Plugin.
"""

from typing import List, Dict, Any
from domains.base import DomainPlugin, DomainMetric, DomainTool, PluginRegistry
from domains.cse.domain_prompt import CSE_SYSTEM_ENHANCEMENT
from domains.cse.domain_metrics import CSE_METRICS
from domains.cse.domain_tools import CSE_TOOLS, estimate_split_and_validation


class CSEPlugin(DomainPlugin):
    @property
    def domain_key(self) -> str:
        return "cse"

    @property
    def display_name(self) -> str:
        return "Computer Science & Engineering (AI / Systems)"

    @property
    def description(self) -> str:
        return "Specialized in Machine Learning, Deep Learning, Edge Computing, Systems, and Algorithmic Analysis."

    def get_system_prompt_enhancements(self) -> str:
        return CSE_SYSTEM_ENHANCEMENT

    def get_domain_metrics(self) -> List[DomainMetric]:
        return CSE_METRICS

    def get_domain_tools(self) -> List[DomainTool]:
        return CSE_TOOLS

    def execute_domain_tool(self, tool_id: str, **kwargs) -> Dict[str, Any]:
        if tool_id == "complexity_estimator":
            n_samples = int(kwargs.get("n_samples", 1000))
            is_imbalanced = bool(kwargs.get("is_imbalanced", False))
            return estimate_split_and_validation(n_samples, is_imbalanced)
        elif tool_id == "model_memory_estimator":
            params = float(kwargs.get("param_count_millions", 10.0))
            return {
                "fp32_vram_mb": round(params * 4, 2),
                "fp16_vram_mb": round(params * 2, 2),
                "int8_vram_mb": round(params * 1, 2),
                "int4_vram_mb": round(params * 0.5, 2),
                "note": "Weights only; KV cache and optimizer states require additional headroom."
            }
        return super().execute_domain_tool(tool_id, **kwargs)


# Register immediately upon module import
PluginRegistry.register(CSEPlugin())
