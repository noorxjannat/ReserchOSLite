"""
Computer Science & AI Domain Metrics.
"""

from typing import List
from domains.base import DomainMetric

CSE_METRICS: List[DomainMetric] = [
    DomainMetric(
        name="Accuracy",
        symbol="Acc",
        description="Proportion of correct predictions over total predictions.",
        unit="%",
        higher_is_better=True,
        benchmark_baseline="> 85%"
    ),
    DomainMetric(
        name="F1-Score (Macro / Micro)",
        symbol="F1",
        description="Harmonic mean of precision and recall; vital for imbalanced classes.",
        unit="",
        higher_is_better=True,
        benchmark_baseline="> 0.80"
    ),
    DomainMetric(
        name="ROC-AUC",
        symbol="AUC",
        description="Area under receiver operating characteristic curve.",
        unit="",
        higher_is_better=True,
        benchmark_baseline="> 0.85"
    ),
    DomainMetric(
        name="Inference Latency",
        symbol="Latency",
        description="Time required to generate a prediction per single query batch.",
        unit="ms",
        higher_is_better=False,
        benchmark_baseline="< 50 ms"
    ),
    DomainMetric(
        name="Computational FLOPs",
        symbol="GFLOPs",
        description="Floating-point operations per second to gauge computational complexity.",
        unit="GFLOPs",
        higher_is_better=False,
        benchmark_baseline="Model dependent"
    ),
    DomainMetric(
        name="Parameter Count",
        symbol="Params",
        description="Total trainable parameters determining model capacity and VRAM usage.",
        unit="Millions",
        higher_is_better=False,
        benchmark_baseline="Edge deployable < 25M"
    )
]
