"""
Computer Science & AI Domain Tools.
"""

from typing import Dict, Any, List
from domains.base import DomainTool

CSE_TOOLS: List[DomainTool] = [
    DomainTool(
        tool_id="complexity_estimator",
        name="Algorithmic Complexity & Split Analyzer",
        description="Analyzes sample size, feature dimension, and recommends training/validation/test split and k-fold cross validation configuration.",
        parameters={"n_samples": "int", "n_features": "int", "is_imbalanced": "bool"}
    ),
    DomainTool(
        tool_id="model_memory_estimator",
        name="Neural Memory & Footprint Estimator",
        description="Estimates parameter memory requirements for 32-bit, 16-bit, and 8-bit quantized precision.",
        parameters={"param_count_millions": "float"}
    )
]


def estimate_split_and_validation(n_samples: int, is_imbalanced: bool = False) -> Dict[str, Any]:
    """Calculate recommended sample splitting."""
    if n_samples < 500:
        return {
            "strategy": "Stratified K-Fold Cross-Validation (k=5 or 10)",
            "test_split_ratio": 0.2,
            "caution": "Small sample size. Avoid single train/test split to prevent high variance.",
            "synthetic_balancing": "SMOTE recommended if class ratio > 4:1" if is_imbalanced else "Not needed"
        }
    elif n_samples < 50000:
        return {
            "strategy": "Stratified Train / Validation / Test Split",
            "train_ratio": 0.70,
            "val_ratio": 0.15,
            "test_ratio": 0.15,
            "caution": "Ensure seed is fixed across runs."
        }
    else:
        return {
            "strategy": "Held-out Test Split",
            "train_ratio": 0.85,
            "val_ratio": 0.075,
            "test_ratio": 0.075,
            "caution": "Sufficient large-scale data."
        }
