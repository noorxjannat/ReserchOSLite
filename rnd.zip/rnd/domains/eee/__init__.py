"""
Electrical & Electronics Engineering Plugin.
"""

from typing import List, Dict, Any
from domains.base import DomainPlugin, DomainMetric, DomainTool, PluginRegistry
from domains.eee.domain_prompt import EEE_SYSTEM_ENHANCEMENT
from domains.eee.domain_metrics import EEE_METRICS
from domains.eee.domain_tools import EEE_TOOLS, check_thd_compliance


class EEEPlugin(DomainPlugin):
    @property
    def domain_key(self) -> str:
        return "eee"

    @property
    def display_name(self) -> str:
        return "Electrical & Electronics Engineering (Power / Microgrids / Control)"

    @property
    def description(self) -> str:
        return "Specialized in Power Electronics, Smart Grids, Harmonic Analysis, Control Systems, and Renewable Energy Integration."

    def get_system_prompt_enhancements(self) -> str:
        return EEE_SYSTEM_ENHANCEMENT

    def get_domain_metrics(self) -> List[DomainMetric]:
        return EEE_METRICS

    def get_domain_tools(self) -> List[DomainTool]:
        return EEE_TOOLS

    def execute_domain_tool(self, tool_id: str, **kwargs) -> Dict[str, Any]:
        if tool_id == "thd_compliance_checker":
            v_kv = float(kwargs.get("voltage_kv", 0.4))
            thd = float(kwargs.get("thd_percent", 4.2))
            return check_thd_compliance(v_kv, thd)
        elif tool_id == "efficiency_loss_breakdown":
            pin = float(kwargs.get("pin_watts", 1000.0))
            pout = float(kwargs.get("pout_watts", 950.0))
            loss = max(0.0, pin - pout)
            eff = (pout / pin * 100.0) if pin > 0 else 0.0
            return {
                "efficiency_percent": round(eff, 2),
                "total_loss_watts": round(loss, 2),
                "loss_fraction_percent": round(100.0 - eff, 2),
                "thermal_sinking_requirement": f"Dissipate at least {round(loss * 1.25, 1)} W with safety margin."
            }
        return super().execute_domain_tool(tool_id, **kwargs)


# Register immediately upon module import
PluginRegistry.register(EEEPlugin())
