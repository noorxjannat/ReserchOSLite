"""
Electrical & Electronics Engineering Domain Metrics.
"""

from typing import List
from domains.base import DomainMetric

EEE_METRICS: List[DomainMetric] = [
    DomainMetric(
        name="Total Harmonic Distortion",
        symbol="THD",
        description="Ratio of the sum of powers of all harmonic components to the power of the fundamental frequency.",
        unit="%",
        higher_is_better=False,
        benchmark_baseline="< 5.0% (IEEE 519 Standard)"
    ),
    DomainMetric(
        name="Power Conversion Efficiency",
        symbol="η (Efficiency)",
        description="Ratio of useful electrical output power to input power.",
        unit="%",
        higher_is_better=True,
        benchmark_baseline="> 95.0% in modern converters"
    ),
    DomainMetric(
        name="Voltage Regulation",
        symbol="VR",
        description="Percentage change in terminal voltage from no-load to full-load.",
        unit="%",
        higher_is_better=False,
        benchmark_baseline="< ±3% for distribution grids"
    ),
    DomainMetric(
        name="Power Factor",
        symbol="PF",
        description="Ratio of real power absorbed by the load to the apparent power flowing in the circuit.",
        unit="",
        higher_is_better=True,
        benchmark_baseline="> 0.95 lagging/unity"
    ),
    DomainMetric(
        name="Signal-to-Noise Ratio",
        symbol="SNR",
        description="Ratio of the power of a signal to the power of background noise.",
        unit="dB",
        higher_is_better=True,
        benchmark_baseline="> 30 dB"
    ),
    DomainMetric(
        name="Settling Time / Rise Time",
        symbol="Ts / Tr",
        description="Time required for transient response curves to reach and stay within an error band (e.g., 2%).",
        unit="ms",
        higher_is_better=False,
        benchmark_baseline="Depends on converter frequency"
    )
]
