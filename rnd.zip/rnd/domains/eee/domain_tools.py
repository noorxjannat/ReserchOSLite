"""
Electrical & Electronics Engineering Domain Tools.
"""

from typing import Dict, Any, List
from domains.base import DomainTool

EEE_TOOLS: List[DomainTool] = [
    DomainTool(
        tool_id="thd_compliance_checker",
        name="IEEE 519 Harmonic Compliance Evaluator",
        description="Checks simulated or measured voltage/current THD against IEEE 519 recommended practice boundaries.",
        parameters={"voltage_kv": "float", "thd_percent": "float"}
    ),
    DomainTool(
        tool_id="efficiency_loss_breakdown",
        name="Converter Power Loss Breakdown",
        description="Estimates conduction losses, switching losses, and magnetic core losses.",
        parameters={"pin_watts": "float", "pout_watts": "float"}
    )
]


def check_thd_compliance(voltage_kv: float, thd_percent: float) -> Dict[str, Any]:
    """Evaluate THD compliance according to IEEE 519 standards."""
    if voltage_kv <= 1.0:
        limit = 8.0  # IEEE 519 low voltage limit
    elif voltage_kv <= 69.0:
        limit = 5.0  # General distribution
    else:
        limit = 2.5  # High voltage transmission

    compliant = thd_percent <= limit
    return {
        "thd_measured_percent": thd_percent,
        "ieee519_limit_percent": limit,
        "is_compliant": compliant,
        "recommendation": (
            "THD within acceptable IEEE 519 standard."
            if compliant
            else f"Exceeds IEEE 519 limit of {limit}%. Recommend LC/LCL low-pass filtering or active power filtering (APF)."
        )
    }
