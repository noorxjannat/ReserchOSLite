"""
Genetic Engineering & Bioinformatics Plugin.
"""

from typing import List, Dict, Any
from domains.base import DomainPlugin, DomainMetric, DomainTool, PluginRegistry
from domains.genetics.domain_prompt import GENETICS_SYSTEM_ENHANCEMENT
from domains.genetics.domain_metrics import GENETICS_METRICS
from domains.genetics.domain_tools import GENETICS_TOOLS, evaluate_volcano_significance


class GeneticsPlugin(DomainPlugin):
    @property
    def domain_key(self) -> str:
        return "genetics"

    @property
    def display_name(self) -> str:
        return "Genetic Engineering & Bioinformatics (Genomics / CRISPR / RNA-Seq)"

    @property
    def description(self) -> str:
        return "Specialized in Differential Gene Expression, RNA-Sequencing, CRISPR-Cas targeting, Pathway Enrichment, and Variant Analysis."

    def get_system_prompt_enhancements(self) -> str:
        return GENETICS_SYSTEM_ENHANCEMENT

    def get_domain_metrics(self) -> List[DomainMetric]:
        return GENETICS_METRICS

    def get_domain_tools(self) -> List[DomainTool]:
        return GENETICS_TOOLS

    def execute_domain_tool(self, tool_id: str, **kwargs) -> Dict[str, Any]:
        if tool_id == "volcano_threshold_evaluator":
            log2_fc = float(kwargs.get("log2_fc", 1.5))
            padj = float(kwargs.get("padj", 0.01))
            fc_cutoff = float(kwargs.get("fc_cutoff", 1.0))
            p_cutoff = float(kwargs.get("p_cutoff", 0.05))
            return evaluate_volcano_significance(log2_fc, padj, fc_cutoff, p_cutoff)
        elif tool_id == "sample_power_calculator":
            reps = int(kwargs.get("n_replicates", 3))
            fc = float(kwargs.get("target_fc", 2.0))
            power = min(0.99, max(0.40, 0.50 + 0.12 * (reps - 2) + 0.10 * (fc - 1.5)))
            return {
                "biological_replicates": reps,
                "target_fold_change": fc,
                "estimated_statistical_power": round(power, 2),
                "is_adequate": reps >= 3,
                "recommendation": "Adequate power for discovery RNA-seq" if reps >= 3 else "High false discovery risk. Minimum 3 biological replicates strongly recommended by ENCODE guidelines."
            }
        return super().execute_domain_tool(tool_id, **kwargs)


# Register immediately upon module import
PluginRegistry.register(GeneticsPlugin())
