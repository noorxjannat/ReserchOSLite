"""
Genetic Engineering & Bioinformatics Domain Metrics.
"""

from typing import List
from domains.base import DomainMetric

GENETICS_METRICS: List[DomainMetric] = [
    DomainMetric(
        name="Log2 Fold Change",
        symbol="log2FC",
        description="Magnitude of differential expression between treated and control biological conditions.",
        unit="",
        higher_is_better=True,
        benchmark_baseline="|log2FC| >= 1.0 (2-fold difference)"
    ),
    DomainMetric(
        name="Adjusted P-Value / FDR",
        symbol="q-val / padj",
        description="Benjamini-Hochberg false discovery rate correction for multiple testing hypothesis tests.",
        unit="",
        higher_is_better=False,
        benchmark_baseline="< 0.05 (Statistical significance threshold)"
    ),
    DomainMetric(
        name="Transcripts Per Million",
        symbol="TPM",
        description="Gene expression quantification normalized for sequencing depth and gene transcript length.",
        unit="TPM",
        higher_is_better=True,
        benchmark_baseline="TPM > 1.0 detectable expression"
    ),
    DomainMetric(
        name="Phred Quality Score",
        symbol="Q-Score",
        description="Logarithmic metric of sequencing base call accuracy.",
        unit="Q",
        higher_is_better=True,
        benchmark_baseline="Q30 (99.9% base call accuracy)"
    ),
    DomainMetric(
        name="Sequencing Depth / Coverage",
        symbol="Coverage",
        description="Average number of sequencing reads covering a given nucleotide in the reference genome.",
        unit="x",
        higher_is_better=True,
        benchmark_baseline=">= 30x WGS / >= 20M reads RNA-seq"
    ),
    DomainMetric(
        name="CRISPR On-Target vs Off-Target Ratio",
        symbol="Specificity Ratio",
        description="Ratio of cleavage at intended genomic locus relative to detected homologous non-target sites.",
        unit="",
        higher_is_better=True,
        benchmark_baseline="> 100:1 ratio"
    )
]
