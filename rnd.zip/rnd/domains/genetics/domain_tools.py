"""
Genetic Engineering & Bioinformatics Domain Tools.
"""

from typing import Dict, Any, List
import math
from domains.base import DomainTool

GENETICS_TOOLS: List[DomainTool] = [
    DomainTool(
        tool_id="volcano_threshold_evaluator",
        name="Volcano Plot Significance Filter",
        description="Assesses whether a gene candidate qualifies as significantly up-regulated or down-regulated based on log2FC and adjusted p-value.",
        parameters={"log2_fc": "float", "padj": "float", "fc_cutoff": "float", "p_cutoff": "float"}
    ),
    DomainTool(
        tool_id="sample_power_calculator",
        name="RNA-Seq Biological Replicate Power Estimator",
        description="Estimates statistical power based on biological replicate count, coefficient of variation, and fold change target.",
        parameters={"n_replicates": "int", "target_fc": "float"}
    )
]


def evaluate_volcano_significance(
    log2_fc: float,
    padj: float,
    fc_cutoff: float = 1.0,
    p_cutoff: float = 0.05
) -> Dict[str, Any]:
    """Classify differential expression candidate."""
    neg_log10_p = -math.log10(padj) if padj > 0 else 300.0

    if padj < p_cutoff and log2_fc >= fc_cutoff:
        status = "Significantly Up-Regulated"
        color = "#2ecc71"
    elif padj < p_cutoff and log2_fc <= -fc_cutoff:
        status = "Significantly Down-Regulated"
        color = "#e74c3c"
    elif padj < p_cutoff and abs(log2_fc) < fc_cutoff:
        status = "Statistically Significant but Below Fold Threshold"
        color = "#f39c12"
    else:
        status = "Non-Significant"
        color = "#95a5a6"

    return {
        "status": status,
        "log2_fc": log2_fc,
        "padj": padj,
        "neg_log10_padj": round(neg_log10_p, 3),
        "is_biologically_relevant": "Significantly" in status,
        "color_code": color
    }
