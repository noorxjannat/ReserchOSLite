# ResearchPilot AI - Project Context & Handover Dossier

**"An Autonomous Multi-Agent Research Workflow Assistant"**  
*Open-Source Hacktoberfest MVP*

---

## 📌 Executive Summary

ResearchPilot AI is a production-grade, modular multi-agent scientific workspace designed to guide undergraduate students, MSc/PhD candidates, and scientific researchers from an initial research curiosity into a structured, publication-ready research blueprint.

Rather than implementing a monolithic chatbot, the platform orchestrates a virtual AI research team across a domain-agnostic core and domain-specific plugin architecture.

- **Primary Repository Location**: [`ResearchPilot-AI`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI)
- **Active Workspace Recommendation**: Set `C:\Users\Noor E Jannat Mawa\.gemini\antigravity-ide\scratch\ResearchPilot-AI` as the active workspace in the IDE.
- **Verification Status**: **100% Passing Test Suite (22/22 Tests in Pytest)**.

---

## 🏛️ Architecture & System Blueprint

```
+-----------------------------------------------------------------------------------------+
|                                    User Research Idea                                   |
+-----------------------------------------------------------------------------------------+
                                             │
                                             ▼
+-----------------------------------------------------------------------------------------+
|                                 Research Director Agent                                 |
|                       (StateGraph orchestrator & workflow telemetry)                    |
+-----------------------------------------------------------------------------------------+
       │                  │                  │                  │                  │
       ▼                  ▼                  ▼                  ▼                  ▼
+--------------+   +--------------+   +--------------+   +--------------+   +--------------+
| Topic Agent  |──>| Literature   |──>|  Gap Agent   |──>| Methodology  |──>| Report Agent |
| (Taxonomy &  |   | Agent        |   | (White-space |   | Agent (Study |   | (Structured  |
| Challenges)  |   | (arXiv + S2) |   |  Synthesis)  |   |  Protocols)  |   |  Blueprint)  |
+--------------+   +--------------+   +--------------+   +--------------+   +--------------+
                                                                                   ▲
                                                                                   │
                                      +────────────────────────────────────────────+
                                      │ Empirical Data Agent & Scientific RAG
                                      │ (Descriptive Stats, ML Models, PDF QA)
```

---

## 📦 Phase-by-Phase Completion Log

### Phase 1: Core Multi-Agent Engine & Backend Pipeline ✅ (COMPLETED)
- **Environment & Configuration**:
  - [`config.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/config.py): Pydantic settings loading `.env` with fallback handling.
  - [`.env.example`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/.env.example): Environment variable template for Gemini, OpenAI, and Semantic Scholar.
  - [`requirements.txt`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/requirements.txt): Fully pinned dependencies.
- **Universal LLM Abstraction Layer**:
  - [`backend/services/llm_service.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/services/llm_service.py): Unified adapter for **Google Gemini API**, **OpenAI API**, and an intelligent **Mock Scientific Engine** for zero-cost offline testing.
- **Literature Intelligence Client**:
  - [`backend/services/paper_search.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/services/paper_search.py): Live search across arXiv Atom XML and Semantic Scholar Graph API with structured aspect extraction.
- **Domain Plugin Architecture**:
  - [`domains/base.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/domains/base.py): Abstract `DomainPlugin` and singleton `PluginRegistry`.
  - [`domains/cse/`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/domains/cse/): Metrics (Accuracy, F1, Latency, FLOPs), Split & VRAM calculation tools.
  - [`domains/eee/`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/domains/eee/): Metrics (THD %, Efficiency, Voltage Regulation), IEEE 519 compliance checker tool.
  - [`domains/genetics/`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/domains/genetics/): Metrics (log2FC, FDR/q-value, TPM), Volcano threshold filter and replicate power calculator.
- **Specialized Multi-Agent Framework**:
  - [`backend/agents/topic_agent.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/agents/topic_agent.py): Domain classification, keyword mining, and challenge mapping.
  - [`backend/agents/literature_agent.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/agents/literature_agent.py): Literature discovery and scholarly narrative synthesis.
  - [`backend/agents/gap_agent.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/agents/gap_agent.py): White-space matrix and high-impact contribution opportunities.
  - [`backend/agents/methodology_agent.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/agents/methodology_agent.py): Pipeline design, baseline selection, and metric targets.
  - [`backend/agents/report_agent.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/agents/report_agent.py): Compiles Markdown & LaTeX manuscripts.
  - [`backend/agents/research_director.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/agents/research_director.py): Master orchestrator and StateGraph coordinator.
- **FastAPI Backend Application**:
  - [`backend/main.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/main.py): Full REST API with Swagger documentation at `/api/docs`.

---

### Phase 2: RAG Pipeline, Document Processing & Empirical Data Agent ✅ (COMPLETED)
- **Scientific Document Processor**:
  - [`backend/services/document_processor.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/services/document_processor.py): PDF parsing and sentence-level section-aware chunking.
- **Scientific RAG Engine**:
  - [`backend/rag/embeddings.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/rag/embeddings.py): Universal document embedding generator.
  - [`backend/rag/vector_store.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/rag/vector_store.py): Cosine similarity search, persistence, and defensive dimension alignment.
  - [`backend/rag/retriever.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/rag/retriever.py): Grounded QA engine answering: *"According to previous studies, what methods are commonly used?"*.
- **Empirical Data Analysis Engine**:
  - [`analysis/statistics.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/analysis/statistics.py): Descriptive statistics, IQR, skewness, and Pearson correlation matrices.
  - [`analysis/visualization.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/analysis/visualization.py): Plotly distribution histograms, bivariate scatter plots, correlation heatmaps, feature importance bar charts, and RNA-Seq volcano plots.
  - [`analysis/ml_models.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/analysis/ml_models.py): Automated Classification (Logistic Regression, Random Forest, Gradient Boosting) and Regression (Ridge, Random Forest Regressor, Gradient Boosting Regressor).
- **Data Analysis Agent**:
  - [`backend/agents/data_agent.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/backend/agents/data_agent.py): Translates empirical figures and ML benchmarks into scientific prose.
- **Demonstration Datasets** (with clear scientific caveat stamps):
  - [`data/datasets/cse_edge_faults.csv`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/data/datasets/cse_edge_faults.csv) (IoT sensor fault classification).
  - [`data/datasets/eee_grid_stability.csv`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/data/datasets/eee_grid_stability.csv) (Microgrid harmonics and voltage stability regression).
  - [`data/datasets/genetics_rna_diff_expr.csv`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/data/datasets/genetics_rna_diff_expr.csv) (RNA-Seq differential expression).

---

### Phase 3: Scientific Dashboard & Open-Source Packaging ✅ (COMPLETED)
- **Streamlit Scientific Dashboard**:
  - [`app.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/app.py): Multi-stage workflow dashboard:
    1. *Research Input & Director*
    2. *Literature Explorer & RAG*
    3. *Research Gap Matrix*
    4. *Methodology Designer & Domain Calculators*
    5. *Empirical Data Lab*
    6. *Final Blueprint & Markdown/LaTeX Export*
- **Convenience Multi-Service Runner**:
  - [`run.py`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/run.py): Starts frontend (`--frontend`), backend (`--backend`), or both concurrently (`--all`).
- **Open-Source Repository Assets**:
  - [`README.md`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/README.md): Hacktoberfest documentation, badges, architecture diagrams, and quickstart.
  - [`CONTRIBUTING.md`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/CONTRIBUTING.md): Hacktoberfest contribution guidelines and plugin authoring tutorial.
  - [`LICENSE`](file:///C:/Users/Noor%20E%20Jannat%20Mawa/.gemini/antigravity-ide/scratch/ResearchPilot-AI/LICENSE): Apache 2.0 Open Source License.

---

## 🧪 Test Suite Verification Matrix

Command executed: `python -m pytest -v`

| Test File | Test Case | Status |
| :--- | :--- | :---: |
| `tests/test_agents.py` | `test_topic_understanding_agent` | **PASSED** |
| `tests/test_agents.py` | `test_literature_intelligence_agent` | **PASSED** |
| `tests/test_agents.py` | `test_research_gap_agent` | **PASSED** |
| `tests/test_agents.py` | `test_methodology_agent` | **PASSED** |
| `tests/test_agents.py` | `test_report_generator_agent` | **PASSED** |
| `tests/test_agents.py` | `test_research_director_full_workflow` | **PASSED** |
| `tests/test_api.py` | `test_api_health` | **PASSED** |
| `tests/test_api.py` | `test_api_domains` | **PASSED** |
| `tests/test_api.py` | `test_api_research_workflow` | **PASSED** |
| `tests/test_api.py` | `test_api_domain_tool_execution` | **PASSED** |
| `tests/test_data_analysis.py` | `test_compute_descriptive_statistics` | **PASSED** |
| `tests/test_data_analysis.py` | `test_compute_correlation_matrix` | **PASSED** |
| `tests/test_data_analysis.py` | `test_train_classification_models` | **PASSED** |
| `tests/test_data_analysis.py` | `test_train_regression_models` | **PASSED** |
| `tests/test_data_analysis.py` | `test_data_analysis_agent` | **PASSED** |
| `tests/test_data_analysis.py` | `test_document_processor_and_rag` | **PASSED** |
| `tests/test_paper_search.py` | `test_paper_search_curated_fallback` | **PASSED** |
| `tests/test_paper_search.py` | `test_paper_search_deduplication` | **PASSED** |
| `tests/test_plugins.py` | `test_registered_plugins` | **PASSED** |
| `tests/test_plugins.py` | `test_cse_plugin_metrics_and_tools` | **PASSED** |
| `tests/test_plugins.py` | `test_eee_plugin_metrics_and_tools` | **PASSED** |
| `tests/test_plugins.py` | `test_genetics_plugin_metrics_and_tools` | **PASSED** |

**Summary**: 22 passed in 27s (100% Pass Rate).

---

## 🚀 How to Run the Prototype

From `C:\Users\Noor E Jannat Mawa\.gemini\antigravity-ide\scratch\ResearchPilot-AI`:

1. **Launch the Streamlit Scientific Dashboard**:
   ```powershell
   python run.py --frontend
   ```
   Open `http://localhost:8501`.

2. **Launch the FastAPI Backend**:
   ```powershell
   python run.py --backend
   ```
   Open Swagger UI at `http://127.0.0.1:8000/api/docs`.

3. **Run All Unit Tests**:
   ```powershell
   python -m pytest -v
   ```
