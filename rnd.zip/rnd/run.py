"""
ResearchPilot AI - Unified Application Launcher.

Starts FastAPI Backend server and/or Streamlit Scientific Dashboard.
"""

import sys
import os
import argparse
import subprocess
from config import settings


def run_backend():
    """Start FastAPI uvicorn server."""
    import uvicorn
    print(f"[*] Starting ResearchPilot AI Backend at http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}")
    print(f"[*] Swagger API Docs: http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}/api/docs")
    uvicorn.run("backend.main:app", host=settings.BACKEND_HOST, port=settings.BACKEND_PORT, reload=settings.DEBUG)


def run_frontend():
    """Start Streamlit frontend dashboard."""
    print(f"[*] Launching ResearchPilot AI Streamlit Dashboard on port {settings.FRONTEND_PORT}...")
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        "app.py",
        "--server.port",
        str(settings.FRONTEND_PORT),
        "--server.headless",
        "true"
    ]
    subprocess.run(cmd)


def main():
    parser = argparse.ArgumentParser(description="ResearchPilot AI Application Runner")
    parser.add_argument("--backend", action="store_true", help="Launch FastAPI backend API server")
    parser.add_argument("--frontend", action="store_true", help="Launch Streamlit scientific dashboard")
    parser.add_argument("--all", action="store_true", help="Launch both backend and frontend")

    args = parser.parse_args()

    if args.backend:
        run_backend()
    elif args.frontend or len(sys.argv) == 1:
        run_frontend()
    elif args.all:
        import threading
        t = threading.Thread(target=run_backend, daemon=True)
        t.start()
        run_frontend()


if __name__ == "__main__":
    main()
