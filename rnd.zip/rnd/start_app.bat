@echo off
cd D:\CODE\rnd
echo Starting ResearchPilot AI...
echo.
echo Making sure statsmodels is installed...
python -m pip install --quiet statsmodels 2>&1 | find "Installing" >NUL
echo.
echo Starting Streamlit frontend on port 8501...
python -m streamlit run app.py --server.headless true --server.port 8501 2>&1 | find "Local URL:"
timeout /t 10 >NUL
echo.
echo If you see "Local URL:" above, copy that link and open it in your browser.
echo.
echo If the window doesn't open automatically, paste the URL into:
echo.
echo   http://localhost:8501
echo.
pause