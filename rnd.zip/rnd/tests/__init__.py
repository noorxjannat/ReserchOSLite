"""
Test suite package for ResearchPilot AI.
"""
