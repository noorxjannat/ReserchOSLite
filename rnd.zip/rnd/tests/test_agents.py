"""
Unit and Integration tests for Research Agents and Director Workflow.
"""

import pytest
from backend.agents.topic_agent import TopicUnderstandingAgent
from backend.agents.literature_agent import LiteratureIntelligenceAgent
from backend.agents.gap_agent import ResearchGapAgent
from backend.agents.methodology_agent import MethodologyAgent
from backend.agents.report_agent import ReportGeneratorAgent
from backend.agents.research_director import ResearchDirectorAgent
from backend.services.llm_service import MockLLMClient


def test_topic_understanding_agent():
    agent = TopicUnderstandingAgent(llm_service=MockLLMClient())
    analysis = agent.analyze_topic("AI for plant disease detection in agricultural fields")
    assert analysis.domain
    assert len(analysis.keywords) >= 3
    assert len(analysis.research_challenges) >= 2


def test_literature_intelligence_agent():
    mock_llm = MockLLMClient()
    topic_agent = TopicUnderstandingAgent(llm_service=mock_llm)
    topic_analysis = topic_agent.analyze_topic("Deep Learning in Microgrids")

    lit_agent = LiteratureIntelligenceAgent(llm_service=mock_llm)
    corpus = lit_agent.discover_literature(topic_analysis, max_papers=4)
    assert len(corpus.papers) > 0
    assert corpus.synthesis_summary


def test_research_gap_agent():
    mock_llm = MockLLMClient()
    topic_agent = TopicUnderstandingAgent(llm_service=mock_llm)
    topic_analysis = topic_agent.analyze_topic("CRISPR Off-Target Prediction with GNNs")

    lit_agent = LiteratureIntelligenceAgent(llm_service=mock_llm)
    corpus = lit_agent.discover_literature(topic_analysis, max_papers=3)

    gap_agent = ResearchGapAgent(llm_service=mock_llm)
    gap_analysis = gap_agent.identify_gaps(topic_analysis, corpus)
    assert len(gap_analysis.existing_approaches) > 0
    assert len(gap_analysis.common_limitations) > 0
    assert len(gap_analysis.possible_contributions) > 0
    assert gap_analysis.primary_gap_statement


def test_methodology_agent():
    mock_llm = MockLLMClient()
    topic_agent = TopicUnderstandingAgent(llm_service=mock_llm)
    topic_analysis = topic_agent.analyze_topic("Predictive Maintenance in Wind Turbines")

    lit_agent = LiteratureIntelligenceAgent(llm_service=mock_llm)
    corpus = lit_agent.discover_literature(topic_analysis, max_papers=3)

    gap_agent = ResearchGapAgent(llm_service=mock_llm)
    gap_analysis = gap_agent.identify_gaps(topic_analysis, corpus)

    methodology_agent = MethodologyAgent(llm_service=mock_llm)
    blueprint = methodology_agent.design_methodology(topic_analysis, gap_analysis)
    assert blueprint.study_type
    assert len(blueprint.pipeline_stages) >= 4
    assert len(blueprint.evaluation_metrics) >= 1


def test_report_generator_agent():
    mock_llm = MockLLMClient()
    topic_agent = TopicUnderstandingAgent(llm_service=mock_llm)
    topic_analysis = topic_agent.analyze_topic("Autonomous Drones for Forest Fire Detection")

    lit_agent = LiteratureIntelligenceAgent(llm_service=mock_llm)
    corpus = lit_agent.discover_literature(topic_analysis, max_papers=3)

    gap_agent = ResearchGapAgent(llm_service=mock_llm)
    gap_analysis = gap_agent.identify_gaps(topic_analysis, corpus)

    methodology_agent = MethodologyAgent(llm_service=mock_llm)
    methodology = methodology_agent.design_methodology(topic_analysis, gap_analysis)

    report_agent = ReportGeneratorAgent(llm_service=mock_llm)
    report = report_agent.generate_report(topic_analysis, corpus, gap_analysis, methodology)
    assert report.title
    assert report.abstract
    assert len(report.research_questions) >= 1
    assert len(report.hypotheses) >= 1
    assert "documentclass" in report.latex_content
    assert "# " in report.markdown_content


def test_research_director_full_workflow():
    director = ResearchDirectorAgent(llm_service=MockLLMClient())
    state = director.execute_full_workflow("AI-Driven Energy Management in Smart Grids", domain_preference="eee")
    assert state.is_completed is True
    assert state.topic_analysis is not None
    assert state.literature is not None
    assert state.gap_analysis is not None
    assert state.methodology is not None
    assert state.report is not None
    assert len(state.errors) == 0
    assert len(state.logs) >= 5
