"""
FastAPI Endpoints Integration Tests.
"""

import pytest
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_api_health():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "cse" in data["registered_domains"]


def test_api_domains():
    response = client.get("/api/domains")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 3


def test_api_research_workflow():
    payload = {
        "topic": "Federated Learning for Genomic Privacy",
        "domain_preference": "genetics",
        "provider": "mock"
    }
    response = client.post("/api/research/workflow", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["is_completed"] is True
    assert data["report"] is not None
    assert "title" in data["report"]


def test_api_domain_tool_execution():
    payload = {
        "parameters": {
            "n_samples": 400,
            "is_imbalanced": False
        }
    }
    response = client.post("/api/domains/cse/tools/complexity_estimator", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "strategy" in data
