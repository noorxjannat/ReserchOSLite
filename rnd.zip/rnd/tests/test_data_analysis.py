"""
Unit and Integration tests for Scientific Data Analysis and RAG Engine.
"""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path

from analysis.statistics import compute_descriptive_statistics, compute_correlation_matrix
from analysis.ml_models import train_classification_models, train_regression_models
from backend.agents.data_agent import DataAnalysisAgent
from backend.services.document_processor import DocumentProcessor
from backend.rag.vector_store import ScientificVectorStore
from backend.rag.retriever import ScientificRAGRetriever
from backend.services.llm_service import MockLLMClient


@pytest.fixture
def sample_dataframe():
    np.random.seed(42)
    n = 100
    x1 = np.random.normal(10, 2, n)
    x2 = x1 * 2.5 + np.random.normal(0, 1, n)
    x3 = np.random.uniform(50, 100, n)
    y_cat = np.where(x2 > 25, "Class_A", "Class_B")
    y_reg = x1 * 3.0 + x2 * 1.5 + np.random.normal(0, 0.5, n)

    return pd.DataFrame({
        "feature_1": x1,
        "feature_2": x2,
        "feature_3": x3,
        "category_target": y_cat,
        "continuous_target": y_reg
    })


def test_compute_descriptive_statistics(sample_dataframe):
    stats = compute_descriptive_statistics(sample_dataframe)
    assert stats["total_rows"] == 100
    assert "feature_1" in stats["statistics"]
    f1 = stats["statistics"]["feature_1"]
    assert 9.0 < f1["mean"] < 11.0
    assert f1["iqr"] > 0
    assert "is_approximately_normal" in f1


def test_compute_correlation_matrix(sample_dataframe):
    corr = compute_correlation_matrix(sample_dataframe)
    assert "top_correlated_pairs" in corr
    top = corr["top_correlated_pairs"][0]
    # feature_1 and feature_2 are strongly positively correlated
    assert top["relationship"] == "Strong Positive"
    assert top["correlation"] > 0.85


def test_train_classification_models(sample_dataframe):
    res = train_classification_models(sample_dataframe, target_col="category_target")
    assert res["task_type"] == "Classification"
    assert len(res["benchmark_results"]) == 3
    assert len(res["feature_importances"]) > 0
    rf = [m for m in res["benchmark_results"] if m["model"] == "Random Forest"][0]
    assert rf["accuracy"] > 0.80


def test_train_regression_models(sample_dataframe):
    res = train_regression_models(sample_dataframe, target_col="continuous_target")
    assert res["task_type"] == "Regression"
    assert len(res["benchmark_results"]) == 3
    rf = [m for m in res["benchmark_results"] if m["model"] == "Random Forest Regressor"][0]
    assert rf["r2_score"] > 0.85


def test_data_analysis_agent(sample_dataframe):
    agent = DataAnalysisAgent(llm_service=MockLLMClient())
    report = agent.analyze_dataset(
        sample_dataframe,
        dataset_name="Test Benchmark",
        target_column="continuous_target"
    )
    assert report.dataset_name == "Test Benchmark"
    assert report.statistics_summary is not None
    assert report.correlation_findings is not None
    assert report.ml_benchmark is not None
    assert "CRITICAL NOTICE" in report.experimental_caveat
    assert len(report.scientific_interpretation) > 50


def test_document_processor_and_rag():
    processor = DocumentProcessor(chunk_size=15, chunk_overlap=5)
    sample_text = (
        "Abstract. Deep neural networks achieve high accuracy on plant disease detection. "
        "Methodology. We train a residual architecture using 5-fold cross-validation. "
        "Results. The model attains 98.5% accuracy with 15ms latency."
    )
    chunks = processor.chunk_document(sample_text, doc_id="paper_1", source_title="Sample Study")
    assert len(chunks) >= 2

    # Vector store indexing
    vstore = ScientificVectorStore()
    added = vstore.add_chunks(chunks)
    assert added == len(chunks)

    # Retrieval
    matches = vstore.similarity_search("What methodology is used?", top_k=2)
    assert len(matches) > 0
    assert "Methodology" in matches[0]["text"] or "residual" in matches[0]["text"].lower()

    # RAG QA
    retriever = ScientificRAGRetriever(vector_store=vstore, llm_service=MockLLMClient())
    ans = retriever.query("According to previous studies, what methods are commonly used?")
    assert ans["answer"]
    assert ans["chunks_retrieved"] > 0
