"""
Unit tests for Scientific Paper Search Service.
"""

from backend.services.paper_search import PaperSearchService, ScientificPaper


def test_paper_search_curated_fallback():
    service = PaperSearchService()
    results = service.search("plant disease detection convolutional", max_results=4)
    assert len(results) > 0
    first = results[0]
    assert isinstance(first, ScientificPaper)
    assert first.title
    assert first.method
    assert first.dataset
    assert first.finding
    assert first.limitation


def test_paper_search_deduplication():
    service = PaperSearchService()
    results = service.search("deep learning", max_results=6)
    titles = [p.title.lower() for p in results]
    assert len(titles) == len(set(titles)), "Paper titles should be deduplicated."
