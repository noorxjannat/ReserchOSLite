"""
Unit tests for Domain Plugin Architecture.
"""

import pytest
from domains.base import PluginRegistry
from domains.cse import CSEPlugin
from domains.eee import EEEPlugin
from domains.genetics import GeneticsPlugin


def test_registered_plugins():
    domains = PluginRegistry.list_domains()
    keys = [d["key"] for d in domains]
    assert "cse" in keys
    assert "eee" in keys
    assert "genetics" in keys


def test_cse_plugin_metrics_and_tools():
    plugin = PluginRegistry.get("cse")
    assert plugin is not None
    metrics = plugin.get_domain_metrics()
    metric_names = [m.name for m in metrics]
    assert "Accuracy" in metric_names
    assert "F1-Score (Macro / Micro)" in metric_names

    # Test complexity tool
    res = plugin.execute_domain_tool("complexity_estimator", n_samples=300, is_imbalanced=True)
    assert "Stratified K-Fold" in res["strategy"]
    assert "SMOTE" in res["synthetic_balancing"]

    # Test memory tool
    mem = plugin.execute_domain_tool("model_memory_estimator", param_count_millions=50.0)
    assert mem["fp32_vram_mb"] == 200.0


def test_eee_plugin_metrics_and_tools():
    plugin = PluginRegistry.get("eee")
    assert plugin is not None
    metrics = plugin.get_domain_metrics()
    metric_names = [m.name for m in metrics]
    assert "Total Harmonic Distortion" in metric_names

    # Test THD compliance tool
    compliant = plugin.execute_domain_tool("thd_compliance_checker", voltage_kv=0.4, thd_percent=3.5)
    assert compliant["is_compliant"] is True

    non_compliant = plugin.execute_domain_tool("thd_compliance_checker", voltage_kv=132.0, thd_percent=6.0)
    assert non_compliant["is_compliant"] is False


def test_genetics_plugin_metrics_and_tools():
    plugin = PluginRegistry.get("genetics")
    assert plugin is not None
    metrics = plugin.get_domain_metrics()
    metric_names = [m.name for m in metrics]
    assert "Log2 Fold Change" in metric_names

    # Test volcano tool
    up_reg = plugin.execute_domain_tool("volcano_threshold_evaluator", log2_fc=2.4, padj=0.001)
    assert up_reg["status"] == "Significantly Up-Regulated"

    down_reg = plugin.execute_domain_tool("volcano_threshold_evaluator", log2_fc=-1.8, padj=0.005)
    assert down_reg["status"] == "Significantly Down-Regulated"
